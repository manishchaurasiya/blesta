<?php



Configure::set('WgsLinode.custome_fields', [
    'linode_id' => [
        'label' => Language::_('WgsLinode.custome_fields.linode_id', true),
        'type' => 'text'
    ],
    'root_password' => [
        'label' => Language::_('WgsLinode.custome_fields.password', true),
        'type' => 'password'
    ],
    'config_id' => [
        'label' => Language::_('WgsLinode.custome_fields.config_id', true),
        'type' => 'text'
    ],
    
    'swap_disk_id' => [
        'label' => Language::_('WgsLinode.custome_fields.swap_disk_id', true),
        'type' => 'text'
    ],
    'main_disk_id' => [
        'label' => Language::_('WgsLinode.custome_fields.main_disk_id', true),
        'type' => 'text'
    ],
    'datacenter' => [
        'label' => Language::_('WgsLinode.custome_fields.datacenter', true),
        'type' => 'select',
        'value' => ["name" => "manish"]
    ],
    'reverse_dns' => [
        'label' => Language::_('WgsLinode.custome_fields.reverse_dns', true),
        'type' => 'text'
    ],
    'resoucres_id' => [
        'label' => Language::_('WgsLinode.custome_fields.resoucres_id', true),
        'type' => 'text'
    ],

    'stackscript' => [
        'label' => Language::_('WgsLinode.custome_fields.stackscript', true),
        'type' => 'select',
        'value' => [2,34,5,6,7]
    ],
    'distribution' => [
        'label' => Language::_('WgsLinode.custome_fields.distribution', true),
        'type' => 'select',
        'value' => [1,2,3 ]
    ],
  
]);

?>