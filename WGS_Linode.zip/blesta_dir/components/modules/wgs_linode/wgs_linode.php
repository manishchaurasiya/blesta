<?php

use Blesta\Core\Util\Validate\Server;

class wgsLinode extends Module
{
    public function __construct()
    {
        // Load components required by this module
        Loader::loadComponents($this, ['Input', 'Record']);

        // Load the language required by this module
        Language::loadLang('wgs_linode', null, dirname(__FILE__) . DS . 'language' . DS);

        // Load module config
        $this->loadConfig(dirname(__FILE__) . DS . 'config.json');

        Loader::loadModels($this, ['WgsLinode.WgsLinodeHelper', 'WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeApi', 'Companies', 'WgsLinode.WgsLinodeLicense']);
    }

    public function install()
    {
        return true;
    }

    public function getClientAddFields($package, $vars = null)
    {
        // check product is enabled or not
        if ((int)$this->WgsLinodeHelper->isProductEnabled($package->id)) {
            $customFields = $this->WgsLinodeConfig->customFields;
            $getApiCustomFieldsData = $this->WgsLinodeHelper->getApiCustomFields();
            // set default values
            foreach ($getApiCustomFieldsData as $key => $value) {
                $customFields[$key]["value"] = $value;
            }
            // set labels
            foreach ($customFields as $key => $value) {
                $customFields[$key]["label"] = Language::_('WgsLinode.custom_fields.' . $key, true);
                if (isset($value["admin_only"])) {
                    unset($customFields[$key]);
                }
            }
            $fields = $this->WgsLinodeHelper->generateModuleFields($customFields, (array)$package->meta);

            return $fields;
        } else {
            $this->Input->setErrors(['error' => ["error" => Language::_('WgsLinode.product.!error.status', true)]]);
            return;
        }
    }

    public function getAdminAddFields($package, $vars = null)
    {
        // check product is enabled or not
        if ((int)$this->WgsLinodeHelper->isProductEnabled($package->id)) {
            $customFields = $this->WgsLinodeConfig->customFields;
            $getApiCustomFieldsData = $this->WgsLinodeHelper->getApiCustomFields();
            // set default values
            foreach ($getApiCustomFieldsData as $key => $value) {
                $customFields[$key]["value"] = $value;
            }
            // set labels
            foreach ($customFields as $key => $value) {
                $customFields[$key]["label"] = Language::_('WgsLinode.custom_fields.' . $key, true);
            }

            $fields = $this->WgsLinodeHelper->generateModuleFields($customFields, (isset($vars->meta) ? array_replace_recursive((array)$package->meta, $vars->meta) : (array)$package->meta));
            return $fields;
        } else {
            $this->Input->setErrors(['error' => ["error" => Language::_('WgsLinode.product.!error.status', true)]]);
            return;
        }
    }

    public function getPackageFields($vars = null)
    {
        $package_pricing_id = $vars->pricing["id"][0];
        $packageDetail = $this->WgsLinodeHelper->getModuleClassByPricingId($package_pricing_id);
        // $customFields = $this->WgsLinodeConfig->customFields;

        // check product is enabled or not
        if ($results = $this->WgsLinodeHelper->isProductEnabled($packageDetail->package_id)) {
            $customFields = $this->WgsLinodeConfig->customFields;
            $getApiCustomFieldsData = $this->WgsLinodeHelper->getApiCustomFields();
            // set default values
            foreach ($getApiCustomFieldsData as $key => $value) {
                $customFields[$key]["value"] = $value;
            }
            // set labels
            foreach ($customFields as $key => $value) {
                $customFields[$key]["label"] = Language::_('WgsLinode.custom_fields.' . $key, true);
            }
            //unset datacenter and server images
            foreach ($customFields as $key => $value) {
                if ($key == "server_image" || $key == "datacenter") {
                    unset($customFields[$key]);
                }
            }
            $fields = $this->WgsLinodeHelper->generateModuleFields($customFields, (isset($vars->meta) ? $vars->meta : []));
            return $fields;
        } else {
            $this->Input->setErrors(['error' => ["error" => Language::_('WgsLinode.product.!error.status', true)]]);
            return;
        }
    }

    // add services 
    public function addService($package, array $vars = null, $parent_package = null, $parent_service = null, $status = "pending")
    {
        if (isset($vars['use_module']) && $vars['use_module'] == "true") {
            //check license key valid or not
            $license_key = $this->Companies->getSetting(Configure::get('Blesta.company_id'), "wgs_linode_license_key");
            $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($license_key->value, Configure::get('Blesta.company_id'));
            if ($licenseInfo["status"] != "Active") {
                $this->Input->setErrors(['error' => ["error" => "License key specified is invalid."]]);
                return;
            }
            // get data from linode_product_setting 
            $productSettings = $this->WgsLinodeHelper->getData("linode_product_setting", ["product_id" => $package->id], false);
            if (!(int)$this->WgsLinodeHelper->isProductEnabled($package->id)) {
                $this->Input->setErrors(['error' => ["error" => Language::_('WgsLinode.product.!error.status', true)]]);
                return;
            }
            // get company settings wgs_linode_prefix
            $prefix = $this->Companies->getSetting(Configure::get('Blesta.company_id'), "wgs_linode_prefix");
            //get all requred data
            $serverImage = (isset($vars["meta"]["server_image"]) ? $vars["meta"]["server_image"] : "0");
            $datacenter = (isset($vars["meta"]["datacenter"]) ? $vars["meta"]["datacenter"] : "0");
            $wgsLinodePrivateiIp = (isset($vars["configoptions"]["wgs_linode_private_ip"]) ? true : false);
            $wgsLinodeBackup = (isset($vars["configoptions"]["wgs_linode_backup"]) ? true : false);
            $label = $prefix->value . "_" . (isset($vars["service_id"]) ? $vars["service_id"] : false);
            $rootPassword = $this->WgsLinodeHelper->generateStrongPassword(12);

            //  array of key/value pairs that will be passed to the API
            $data = [
                'region' => $datacenter,
                'type' => $productSettings->linode_plan,
                'label' => $label,
                'backups_enabled' => $wgsLinodeBackup,
                "booted" => true,
                "image" => $serverImage,
                "swap_size" => (int)$productSettings->swap,
                "root_pass" => $rootPassword,
                // "stackscript_id" => (int)$package["meta"]->stackscript,
            ];
            //validate data
            $this->Input->setRules($this->addServiceRules());
            if (!$this->Input->validates($data)) {
                return;
            }
            $settings = $this->WgsLinodeHelper->getConfigSetting();
            $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
            $linodeDetails = $this->WgsLinodeApi->createLinode($data);
            //    $linodeDetails = [];
            $metaData = [];
            //    $linodeDetails['httpcode'] = 200;
            if ($linodeDetails['httpcode'] != 200) {
                // $this->Input->setErrors(['errors' => (array)$errors]);
                $this->Input->setErrors(['errors' => (array)$linodeDetails['result']->errors[0]->reason]);
                return false;
            } else {
                $linode_id = $linodeDetails['result']->id;
                $linode_label = $linodeDetails['result']->label;
                //Assign main disk and swap id
                $getDiskList = $this->WgsLinodeApi->getDisks($linode_id);
                if ($getDiskList['httpcode'] == 200 && isset($getDiskList['result']->data)) {
                    foreach ($getDiskList['result']->data as $value) {
                        if ($value->filesystem == 'ext4') {
                            $main_disk_id = $value->id;
                        }
                        if ($value->filesystem == 'swap') {
                            $swap_disk_id = $value->id;
                        }
                    }
                }
                /*get config lists*/
                $getConfigList = $this->WgsLinodeApi->getConfigList($linode_id);
                if ($getConfigList['httpcode'] == 200 && isset($getConfigList['result']->data)) {
                    foreach ($getConfigList['result']->data as $value) {
                        $config_id = $value->id;
                    }
                }
                // get ips rdns 
                $getRdns = $this->WgsLinodeHelper->ipsLists($linode_id);
                $reverceRdns = isset($getRdns["0"]->rdns) ? $getRdns["0"]->rdns : "";
                // rebooting server
                $this->WgsLinodeApi->serverReBoot($linode_id);
                return [
                    [
                        'key' => "config_id",
                        'value' => isset($config_id) ? $config_id : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "linode_id",
                        'value' => isset($linode_id) ? $linode_id : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "linode_label",
                        'value' => isset($linode_label) ? $linode_label : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "main_disk_id",
                        'value' => isset($main_disk_id) ? $main_disk_id : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "password",
                        'value' => isset($rootPassword) ? $rootPassword : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "resoucres_id",
                        'value' => isset($resoucres_id) ? $resoucres_id : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "reverse_dns",
                        'value' => isset($reverceRdns) ? $reverceRdns : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "stackscript",
                        'value' => isset($stackscript) ? $stackscript : "",
                        'encrypted' => 0
                    ],
                    [
                        'key' => "swap_disk_id",
                        'value' => isset($swap_disk_id) ? $swap_disk_id : "",
                        'encrypted' => 0
                    ],
                ];
            }
        }
        $meta = [];
        if (isset($vars["meta"])) {
            foreach ($vars["meta"] as $key => $value) {
                $meta[$key] = $value;
            }
        }
        return [
            [
                'key' => "meta",
                'value' => $meta,
                'encrypted' => 0
            ]
        ];
    }

    private function addServiceRules()
    {
        $getApiCustomFieldsData = $this->WgsLinodeHelper->getApiCustomFields();
        return [
            'type' => [
                'empty' => [
                    'rule' => 'isEmpty',
                    'negate' => true,
                    'message' => Language::_('WgsLinode.!error.linode_plan.required', true)
                ]
            ],
            'image' => [
                'empty' => [
                    'rule' => 'isEmpty',
                    'negate' => true,
                    'message' => Language::_('WgsLinode.!error.server_image.required', true)
                ],
                'format' => array(
                    'rule' => array("array_key_exists", $getApiCustomFieldsData["server_image"]),
                    'message' => Language::_('WgsLinode.!error.server_image.validate', true)
                )
            ],
            'region' => [
                'empty' => [
                    'rule' => 'isEmpty',
                    'negate' => true,
                    'message' => Language::_('WgsLinode.!error.datacenter.required', true)
                ],
                'format' => array(
                    'rule' => array("array_key_exists", $getApiCustomFieldsData["datacenter"]),
                    'message' => Language::_('WgsLinode.!error.datacenter.region.validate', true)
                )
            ],
        ];
    }

    // suspend services
    /**
     * Suspends the service on the remote server. Sets Input errors on failure,
     * preventing the service from being suspended.
     *
     * @param stdClass $package A stdClass object representing the current package
     * @param stdClass $service A stdClass object representing the current service
     * @param stdClass $parent_package A stdClass object representing the parent
     *  service's selected package (if the current service is an addon service)
     * @param stdClass $parent_service A stdClass object representing the parent
     *  service of the service being suspended (if the current service is an addon service)
     * @return mixed null to maintain the existing meta fields or a numerically
     *  indexed array of meta fields to be stored for this service containing:
     *  - key The key for this meta field
     *  - value The value for this key
     *  - encrypted Whether or not this field should be encrypted (default 0, not encrypted)
     * @see Module::getModule()
     * @see Module::getModuleRow()
     */
    public function suspendService($package, $service, $parent_package = null, $parent_service = null)
    {

        //check license key valid or not
        $license_key = $this->Companies->getSetting(Configure::get('Blesta.company_id'), "wgs_linode_license_key");
        $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($license_key->value, Configure::get('Blesta.company_id'));
        if ($licenseInfo["status"] != "Active") {
            $this->Input->setErrors(['error' => ["error" => "License key specified is invalid."]]);
            return;
        }

        $linodeId = (isset($service->fields["0"]->value["linode_id"]) ? $service->fields["0"]->value["linode_id"] : "");
        $serviceStatus = $this->WgsLinodeHelper->getData("services", ["id" => $service->id], false);
        if ($serviceStatus->status != "active" && !empty($serviceStatus->status)) {
            $errors = "your Service is not active!";
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }
        if (empty($linodeId)) {
            $errors = "Linode id is missing!";
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }

        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $response = $this->WgsLinodeApi->serverShutDown($linodeId);
        if ($response["httpcode"] == 200) {
            return true;
        } else {
            $error = $response['result']->errors[0]->reason;
            $this->Input->setErrors(["errors" => (array)$error]);
            return false;
        }
        // echo"<pre>";
        // print_r($service);
        // die;
        return true;
    }

    // unsuspend services
    /**
     * Unsuspends the service on the remote server. Sets Input errors on failure,
     * preventing the service from being unsuspended.
     *
     * @param stdClass $package A stdClass object representing the current package
     * @param stdClass $service A stdClass object representing the current service
     * @param stdClass $parent_package A stdClass object representing the parent
     *  service's selected package (if the current service is an addon service)
     * @param stdClass $parent_service A stdClass object representing the parent
     *  service of the service being unsuspended (if the current service is an addon service)
     * @return mixed null to maintain the existing meta fields or a numerically
     *  indexed array of meta fields to be stored for this service containing:
     *  - key The key for this meta field
     *  - value The value for this key
     *  - encrypted Whether or not this field should be encrypted (default 0, not encrypted)
     * @see Module::getModule()
     * @see Module::getModuleRow()
     */
    public function unsuspendService($package, $service, $parent_package = null, $parent_service = null)
    {
         //check license key valid or not
         $license_key = $this->Companies->getSetting(Configure::get('Blesta.company_id'), "wgs_linode_license_key");
         $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($license_key->value, Configure::get('Blesta.company_id'));
         if ($licenseInfo["status"] != "Active") {
             $this->Input->setErrors(['error' => ["error" => "License key specified is invalid."]]);
             return;
         }
 
        $linodeId = (isset($service->fields["0"]->value["linode_id"]) ? $service->fields["0"]->value["linode_id"] : "");
        if (empty($linodeId)) {
            $errors = "Linode id is missing!";
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $response = $this->WgsLinodeApi->serverReBoot($linodeId);
        if ($response["httpcode"] == 200) {
            return true;
        } else {
            $error = $response['result']->errors[0]->reason;
            $this->Input->setErrors(["errors" => (array)$error]);
            return false;
        }
        return true;
    }
    // cancle services
    /**
     * Cancels the service on the remote server. Sets Input errors on failure,
     * preventing the service from being canceled.
     *
     * @param stdClass $package A stdClass object representing the current package
     * @param stdClass $service A stdClass object representing the current service
     * @param stdClass $parent_package A stdClass object representing the parent
     *  service's selected package (if the current service is an addon service)
     * @param stdClass $parent_service A stdClass object representing the parent
     *  service of the service being canceled (if the current service is an addon service)
     * @return mixed null to maintain the existing meta fields or a numerically
     *  indexed array of meta fields to be stored for this service containing:
     *  - key The key for this meta field
     *  - value The value for this key
     *  - encrypted Whether or not this field should be encrypted (default 0, not encrypted)
     * @see Module::getModule()
     * @see Module::getModuleRow()
     */
    public function cancelService($package, $service, $parent_package = null, $parent_service = null, $vars = null)
    {
         //check license key valid or not
         $license_key = $this->Companies->getSetting(Configure::get('Blesta.company_id'), "wgs_linode_license_key");
         $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($license_key->value, Configure::get('Blesta.company_id'));
         if ($licenseInfo["status"] != "Active") {
             $this->Input->setErrors(['error' => ["error" => "License key specified is invalid."]]);
             return;
         }
 
        $linodeId = (isset($service->fields["0"]->value["linode_id"]) ? $service->fields["0"]->value["linode_id"] : "");
        if (empty($linodeId)) {
            $errors = "Linode id is missing!";
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $response = $this->WgsLinodeApi->serverShutDown($linodeId);
        if ($response["httpcode"] == 200) {
            return true;
        } else {
            $error = $response['result']->errors[0]->reason;
            $this->Input->setErrors(["errors" => (array)$error]);
            return false;
        }
        return true;
    }

    // get Admin Service Tabs
    public function getAdminTabs($package)
    {
        // The keys (i.e. "myServices") representing the method name of the tab to call when an client clicks on it in the interface
        return [
            'tabServerDetails' => Language::_('WgsLinode.client.tab.my_services.title', true),
        ];
    }
    public function tabServerDetails($package, $service, array $get = null, array $post = null, array $files = null)
    {
        return $this->manageServerDetails("tab_server_details", $package, $service, $get, $post, $files);
    }
    private function manageServerDetails($view, $package, $service, $get, $post, $files)
    {
        $this->view = new View($view, "default");
        // Load the helpers required for this view
        Loader::loadHelpers($this, array("Form", "Html"));
        $services = $service;
        // get region name 

        $datacenter = isset($services->fields["0"]->value["datacenter"]) ? $services->fields["0"]->value["datacenter"] : "";
        $regionName = $this->WgsLinodeHelper->getDataCenterRegion($datacenter);
        $this->view->setDefaultView("components" . DS . "modules" . DS . "wgs_linode" . DS);
        $this->view->set(compact("services", "regionName"));
        // $this->view->set(compact());
        return $this->view->fetch();
    }

    // getClientTabs
    public function getClientTabs($package)
    {
        // The keys (i.e. "myServices") representing the method name of the tab to call when an client clicks on it in the interface
        return [
            'tabMyServices' => Language::_('WgsLinode.client.tab.my_services.title', true),
        ];
    }

    public function tabMyServices($package, $service, array $get = null, array $post = null, array $files = null)
    {
        return $this->manageMyServices("tab_my_services", $package, $service, $get, $post, $files);
    }

    private function manageMyServices($view, $package, $service, $get, $post, $files)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeApi', "Invoices"]);
        $this->view = new View($view, "default");
        // Load the helpers required for this view
        Loader::loadHelpers($this, array("Form", "Html"));
        // get server details
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        //get linode server meta data
        $serverMeta = $this->WgsLinodeHelper->getLinodeId($service);
        $linodeId = 35537513 /*!empty($serverMeta["linode_id"]) ? $serverMeta["linode_id"] : false*/;
        if (empty($linodeId)) {
            $errors =  Language::_('WgsLinode.client.tab.my_services.server.linode_id.not.found', true);
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }
        $linodeServerDetail = $this->WgsLinodeApi->getseverdetails($linodeId);
        if ($linodeServerDetail["httpcode"] != "200" || (isset($linodeServerDetail["result"]->error))) {
            $errors =  Language::_('WgsLinode.client.tab.my_services.server.api.error', true);
            $this->Input->setErrors(['errors' => (array)$errors]);
            return false;
        }
        //get server images
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $images = $this->WgsLinodeApi->getImages();
        $serverImages = [];
        foreach ($images["result"]->data as $key => $value) {
            $serverImages[$value->id] = $value;
        }
        // get active features
        $activeFeatures = $this->WgsLinodeHelper->getData("linode_features", ["product_id" => $package->id], false);
        $features = !empty($activeFeatures->id) ? json_decode($activeFeatures->feature) : "";
        //rebuildImages 
        $rebuildImages = [];
        $imagename = "";
        foreach ($serverImages as $key => $value) {
            if ($key != $linodeServerDetail["result"]->image) {
                $rebuildImages[$key] = $value->label;
            } else {
                $imagename = $value->vendor;
            }
        }
        $rebuildImages = (!empty($rebuildImages) ? $rebuildImages : "");
        $imagename = strtolower($imagename);

        // reset root password 
        if (isset($_POST["reset_root_password"]) && !empty($_POST)) {
            $newPassword = $_POST["reset_root_password"];
            $linodeId = $linodeServerDetail["result"]->id;
            $status = $linodeServerDetail["result"]->status;
            $package_id = $package->id;
            //reset root password
            $response = $this->WgsLinodeHelper->resetRootPassword($newPassword, $linodeId, $status, $package_id);
        }
        //get disk name
        $diskDetails = $this->WgsLinodeApi->getDisks($linodeServerDetail["result"]->id);
        // get server logs
        $serverLogs = $this->WgsLinodeApi->serverLogs();
        $logs = $this->WgsLinodeHelper->getServerLogs($serverLogs["result"]->data, $linodeServerDetail["result"]->id);
        // get region name 
        $regionName = $this->WgsLinodeHelper->getDataCenterRegion($linodeServerDetail["result"]->region);
        //get card with copt to clipboard
        $clienSideCard = $this->WgsLinodeConfig->clienSideCard;
        //get ips 
        $ipList = $this->WgsLinodeHelper->ipsLists($linodeServerDetail["result"]->id);
        // get backup details 
        $snapshotlist = $this->WgsLinodeApi->getBackupDetail($linodeId);
        // get data from linode_invoice
        $invoice = $this->WgsLinodeHelper->getData("linode_invoice", ["service_id" => $service->id, "action" => "enable_backup"], false);
        //reboot linode server 
        if ((count($post)) && ($post["action"]) == "reboot" && (!empty($post["action"]))) {
            $linodeId =  $linodeId  /*$service->fields["0"]->value["linode_id"]*/;
            $response = $this->WgsLinodeApi->serverReBoot($linodeId);
            echo json_encode($response);
            exit();
        }

        //power on 
        if ((count($post)) && (!empty($post["action"]))) {
            $linodeId = $linodeId /*$service->fields["0"]->value["linode_id"]*/;
            if ($post["action"] == "boot") {
                $response = $this->WgsLinodeApi->serverBoot($linodeId);
                echo json_encode($response);
                //    echo json_encode();
                exit();
            } elseif ($post["action"] == "enable_backup") {
                $invoiceData = $this->WgsLinodeHelper->createArrayForInvoice($service);
                $pendingInvoice = $this->WgsLinodeHelper->getData("linode_invoice", ["service_id" => $service->id, "action" => $post["action"], "status" => "unpaid"]);
                // backup enable after 24 hours of disable event occurs
                $dataLog = null;
                $backupStatus = 0;
                foreach ($logs as $key => $log) {
                    if ($log["action"] == 'backups_cancel') {
                        $dataLog = $log;
                        break;
                    }
                }
                if (!empty($dataLog)) {
                    $created = $dataLog["created"];
                    $duration = $dataLog["duration"];
                    $duration = (empty($duration) ? 0 : $duration);
                    $taskduration = "+{$duration} seconds";

                    $time = (strtotime($created));
                    $createdTime = date("Y/m/d H:i:s", strtotime($taskduration, $time));

                    /**Add 25 hr */
                    $createdTime = (strtotime($createdTime));
                    $createdTime2 = date("Y/m/d H:i:s", strtotime("+25 hours", $createdTime));

                    /**now time */
                    $currentTime = date("Y/m/d H:i:s");
                    $backupStatus = (($createdTime2 > $currentTime) ? 1 : 0);


                    if ($backupStatus) {
                        $errors =  "Please wait 24 hours before reactivating backups for this Linode.";
                        echo json_encode(["status" => "error", "msg" => $errors]);
                        exit();
                    }
                }
                // check invoice pending or not

                if (isset($pendingInvoice->id) ? false : true) {
                    $invoiceId = $this->Invoices->add($invoiceData);
                    //inssert data into linode_invoice table
                    $insertData = $this->Record->insert("linode_invoice", ['invoice_id' => $invoiceId, 'service_id' => $service->id, "action" => $post["action"], "status" => "unpaid"]);
                    $errors =  "Invoice has been created please pay!";
                    echo json_encode(["status" => "success", "msg" => $errors]);
                    exit();
                } else {
                    $errors =  "You have already requested for enable backup please pay your invoice. id {$pendingInvoice->invoice_id}!";
                    echo json_encode(["status" => "info", "msg" => $errors]);
                    exit();
                }
                exit();
            } elseif ($post["action"] == "disable_backup") {
                $response = $this->WgsLinodeApi->disableBackup($linodeId);
                echo json_encode($response);
                exit();
            }
            //add ips 
            elseif ($post["action"] == "public_ip") {
                $response = $this->WgsLinodeApi->createIp($linodeId, $public = true);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "private_ip") {
                $response = $this->WgsLinodeApi->createIp($linodeId, $public = false);
                echo json_encode($response);
                exit();
            }
            // delete ip 
            elseif ($post["action"] == "delete_ip") {
                $response = $this->WgsLinodeApi->deleteIp($linodeServerDetail["result"]->id, $post["Address"]);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "edit_ip") {
                $response = $this->WgsLinodeApi->editIpRdns($linodeServerDetail["result"]->id, $post["address"], $post["rDNS"]);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "takeSnapshot") {
                $response = $this->WgsLinodeApi->takeSnapshot($linodeServerDetail["result"]->id, $post["label"]);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "rebuild") {
                $response = $this->WgsLinodeApi->rebuild($linodeId, $post);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "restoreBackup") {
                $response = $this->WgsLinodeApi->backupRestore($linodeId, $post["backupId"]);
                echo json_encode($response);
                exit();
            } elseif ($post["action"] == "resetRoorPassword") {
                if ($linodeServerDetail["result"]->status != "offline") {
                    $resposnse = $this->WgsLinodeApi->serverShutDown($linodeId);
                    // PRINT_R($this->WgsLinodeApi->getseverdetails($linodeId)["result"]->status);
                    while ($this->WgsLinodeApi->getseverdetails($linodeId)["result"]->status == 'shutting_down') {
                        sleep(3);
                    }
                    if ($resposnse["httpcode"] == 200) {
                        $response = $this->WgsLinodeApi->resetRootPassword($linodeId, $post["password"]);
                        // update password in package_meta table
                        $this->Record->where("package_id", "=", $package_id)->where("key", "=", "password")->update("package_meta", ["value" => $newPassword]);
                        //rebooting server
                        $response = $this->WgsLinodeApi->serverReBoot($linodeId);
                        echo json_encode($response);
                        exit();
                    } else {
                        // set error here
                    }
                }
                exit();
            }
        }
        // graph 
        if ((count($post)) && (!empty($post["action"]))) {
            $linodeId = $linodeId /*$service->fields["0"]->value["linode_id"] */;
            // get range from dropdown
            $range = $post['graph_range'];
            if ($range == '30days') {
                $range = date('Y/m');
            } else {
                $range = '';
            }
            $getgraphdetail = $this->WgsLinodeApi->getStats($linodeId, $range);
            if ($post["action"] == "netv6" || $post["action"] == "netv4") {
                $this->WgsLinodeHelper->graphDataIPv4Ip6($getgraphdetail, $post["action"]);
            }
            if ($post["action"] == "cpu") {
                $this->WgsLinodeHelper->graphDataCpu($getgraphdetail, $post["action"]);
            }
            // diskio_graph
            if ($post["action"] == "io") {
                $this->WgsLinodeHelper->graphDataIo($getgraphdetail);
            }
        }
        // echo"</pre>";
        // $this->view->setView('tab_my_services', 'wgs_linode.admin');
        $this->view->setDefaultView("components" . DS . "modules" . DS . "wgs_linode" . DS);
        $this->company_info = $this->Companies->get(Configure::get('Blesta.company_id'));
        $this->module_view_url = Router::makeURI(str_replace('index.php/', '', WEBDIR) . $this->view->view_path . "assets/");
        $this->module_area_link = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $this->company_info->hostname . $this->module_view_url;
        $this->view->set('module_area_link', $this->module_area_link);
        $this->view->set(compact("features", "linodeServerDetail", "rebuildImages", "imagename", "regionName", "clienSideCard", 'serverMeta', "logs", "diskDetails", "ipList", "invoice", "snapshotlist"));
        return $this->view->fetch();
    }
}
