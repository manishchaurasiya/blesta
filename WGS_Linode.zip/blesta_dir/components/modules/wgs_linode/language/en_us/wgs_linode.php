<?php

// Custom Field labels
$lang['WgsLinode.custom_fields.linode_id'] = 'Linode Id';
$lang['WgsLinode.custom_fields.linode_label'] = 'Linode Label';
$lang['WgsLinode.custom_fields.datacenter'] = 'Region';
$lang['WgsLinode.custom_fields.password'] = 'Root Password';
$lang['WgsLinode.custom_fields.config_id'] = 'Config Id';
$lang['WgsLinode.custom_fields.swap_disk_id'] = 'Swap Disk Id';
$lang['WgsLinode.custom_fields.main_disk_id'] = 'Main Disk Id';
$lang['WgsLinode.custom_fields.reverse_dns'] = 'Reverse DNS';
$lang['WgsLinode.custom_fields.resoucres_id'] = 'Resources Id';
$lang['WgsLinode.custom_fields.stackscript'] = 'StackScript';
$lang['WgsLinode.custom_fields.server_image'] = 'distribution|Images';

// config options 
$lang['WgsLinode.config.label.private_ip'] = 'Linode Private IP';
$lang['WgsLinode.config.private_ip'] = 'Private IP';
$lang['WgsLinode.config.values.name.private_ip'] = 'Private IP';
$lang['WgsLinode.config.values.value.linode_private_ip'] = 'Linode Private IP';
$lang['WgsLinode.config.label.backup'] = 'Backup';
$lang['WgsLinode.config.name.linode_backup'] = 'Linode Backup';
$lang['WgsLinode.config.values.name.backup'] = 'Backup';
$lang['WgsLinode.config.values.value.linode_backup'] = 'Linode Backup';


// Success Messages
$lang['WgsLinode.service.activate!success'] = 'Servivce has been';

// Error Messages

$lang['WgsLinode.product.!error.status'] = 'Product is not active. Please check product configuration.';

$lang['WgsLinode.!error.datacenter.required'] = 'Datacenter is required.';
$lang['WgsLinode.!error.server_image.required'] = 'Server Image is required';
$lang['WgsLinode.!error.linode_plan.required'] = 'Linode plan is required';
$lang['WgsLinode.!error.stackscript.required'] = 'stackScript is required';

$lang['WgsLinode.!error.datacenter.region.validate'] = 'Region specified is not valid.';
$lang['WgsLinode.!error.server_image.validate'] = 'Server Image specified is not valid.';
$lang['WgsLinode.!error.stackscript.validate'] = 'stackScript specified is not valid.';


// client side tabs

$lang['WgsLinode.client.tab.my_services.title'] = 'My Services';
$lang['WgsLinode.client.tab.my_services.transfer'] = 'Transfer';
$lang['WgsLinode.client.tab.my_services.vCPUI'] = 'vCPUI';
$lang['WgsLinode.client.tab.my_services.ram'] = 'RAM';
$lang['WgsLinode.client.tab.my_services.disk_local'] = 'Disk local';
$lang['WgsLinode.client.tab.my_services.reboot'] = 'Reboot';
$lang['WgsLinode.client.tab.my_services.power_on'] = 'Power ON';
$lang['WgsLinode.client.tab.my_services.cancel_backup'] = 'Cancel Backup';
$lang['WgsLinode.client.tab.my_services.enable_backup'] = 'Enable Backup';
$lang['WgsLinode.client.tab.my_services.server_and_network_detail'] = 'SERVER AND NETWORK DETAILS';
$lang['WgsLinode.client.tab.my_services.server_name'] = 'Server Name';
$lang['WgsLinode.client.tab.my_services.ipv4'] = 'IPv4';
$lang['WgsLinode.client.tab.my_services.ipv6'] = 'IPv6';
$lang['WgsLinode.client.tab.my_services.operating_system'] = 'Operating System';
$lang['WgsLinode.client.tab.my_services.region'] = 'Region';
$lang['WgsLinode.client.tab.my_services.ssh_access'] = 'SSH Access';
$lang['WgsLinode.client.tab.my_services.last_updated'] = 'Last Updated';


$lang['WgsLinode.client.tab.my_services.disk_storage'] = 'DISK STORAGE';
$lang['WgsLinode.client.tab.my_services.rescue'] = 'RESCUE';
$lang['WgsLinode.client.tab.my_services.rescue.label.dev_sda'] = '/dev/sda';
$lang['WgsLinode.client.tab.my_services.rescue.label.dev_sbd'] = '/dev/sbd';
$lang['WgsLinode.client.tab.my_services.graph.title'] = 'Graphs';
$lang['WgsLinode.client.tab.my_services.graph.select.name.graph_select'] = 'graph_select';
$lang['WgsLinode.client.tab.my_services.graph.select.option.last_24_hours'] = 'Last 24 Hours';
$lang['WgsLinode.client.tab.my_services.graph.select.option.last_30_days'] = 'Last 30 Days';
$lang['WgsLinode.client.tab.my_services.graph.cpu_usage'] = 'CPU Usage';
$lang['WgsLinode.client.tab.my_services.graph.IPv4_traffic'] = 'IPv4 Traffic';
$lang['WgsLinode.client.tab.my_services.graph.IPv6_traffic'] = 'IPv6 Traffic';
$lang['WgsLinode.client.tab.my_services.graph.disk-io'] = 'Disk IO';
$lang['WgsLinode.client.tab.my_services.reset_root_password'] = 'RESET ROOT PASSWORD';
$lang['WgsLinode.client.tab.my_services.btn.reset_root_password'] = 'Reset Root Password';
$lang['WgsLinode.client.tab.my_services.rebuild'] = 'REBUILD';
$lang['WgsLinode.client.tab.my_services.btn.rebuild'] = 'Rebuild';

$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail'] = 'BACKUPS SNAPSHOT DETAIL';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.btn.take_snapshot'] = 'Take Snapshot';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.table.heading.label'] = 'Lable';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.table.heading.date'] = 'Date';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.table.heading.disk'] = 'Disks';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.table.heading.space_required'] = 'Space Required';
$lang['WgsLinode.client.tab.my_services.backup_snapshot_detail.table.heading.action'] = 'Action';
$lang['WgsLinode.client.tab.my_services.ip_list'] = 'IP LIST';
$lang['WgsLinode.client.tab.my_services.ip_list.btn.add_private_ip'] = 'Add Private IP';
$lang['WgsLinode.client.tab.my_services.ip_list.btn.add_public_ip'] = 'Add Public IP';
$lang['WgsLinode.client.tab.my_services.ip_list.btn.edit_ip'] = 'edit_ip';
$lang['WgsLinode.client.tab.my_services.ip_list.btn.delete_ip'] = 'delete_ip';
$lang['WgsLinode.client.tab.my_services.ip_list.table.heading.ip_address'] = 'IP Address';
$lang['WgsLinode.client.tab.my_services.ip_list.table.heading.rdns'] = 'rDNS';
$lang['WgsLinode.client.tab.my_services.ip_list.table.heading.type'] = 'Type';
$lang['WgsLinode.client.tab.my_services.ip_list.table.heading.action'] = 'Action';

$lang['WgsLinode.client.tab.my_services.service_action_log'] = 'SERVER ACTIVE LOG';
$lang['WgsLinode.client.tab.my_services.service_action_log.table.heading.id'] = 'ID';
$lang['WgsLinode.client.tab.my_services.service_action_log.table.heading.action'] = 'ACTION';
$lang['WgsLinode.client.tab.my_services.service_action_log.table.heading.date'] = 'DATE';
$lang['WgsLinode.client.tab.my_services.service_action_log.table.heading.status'] = 'STATUS';


// linode server api error

$lang['WgsLinode.client.tab.my_services.server.api.error'] = 'Server Error!';
$lang['WgsLinode.client.tab.my_services.server.linode_id.not.found'] = 'Your service has been suspended or terminated by admin. please contact to the admin!';

//linode server logs action 

$lang['WgsLinode.client.tab.my_services.log.action.profile_update'] = 'Profile Update';
$lang['WgsLinode.client.tab.my_services.log.action.linode_reboot'] = 'Linode Reboot';
$lang['WgsLinode.client.tab.my_services.log.action.password_reset'] = 'Password Reset';
$lang['WgsLinode.client.tab.my_services.log.action.linode_shutdown'] = 'Linode Shutdown';
$lang['WgsLinode.client.tab.my_services.log.action.lassie_reboot'] = 'Lassie Reboot';
$lang['WgsLinode.client.tab.my_services.log.action.linode_boot'] = 'Linode Boot';
$lang['WgsLinode.client.tab.my_services.log.action.backups_cancel'] = 'Backups Cancel';
$lang['WgsLinode.client.tab.my_services.log.action.backups_enable'] = 'Backups Enable';
$lang['WgsLinode.client.tab.my_services.log.action.notification'] = 'Notification';
$lang['WgsLinode.client.tab.my_services.log.action.linode_create'] = 'Linode Create';
$lang['WgsLinode.client.tab.my_services.log.action.linode_addip'] = 'Linode addip';
$lang['WgsLinode.client.tab.my_services.log.action.linode_rebuild'] = 'Linode Rebuild';
$lang['WgsLinode.client.tab.my_services.log.action.linode_snapshot'] = 'Linode Snapshot';
$lang['WgsLinode.client.tab.my_services.log.action.backups_restore'] = 'Backups Restore';

// admin tab (my services)
$lang['WgsLinode.admin.tab.my_services.title'] = 'My Services';
$lang['WgsLinode.admin.tab.my_services.list.config_id'] = 'Config Id';
$lang['WgsLinode.admin.tab.my_services.list.linode_id'] = 'Linode Id';
$lang['WgsLinode.admin.tab.my_services.list.linode_label'] = 'Linode Label';
$lang['WgsLinode.admin.tab.my_services.list.main_disk_id'] = 'Main Disk Id';
$lang['WgsLinode.admin.tab.my_services.list.password'] = 'Password';
$lang['WgsLinode.admin.tab.my_services.list.resoucres_id'] = 'Resoucres Id';
$lang['WgsLinode.admin.tab.my_services.list.reverse_dns'] = 'Reverse rDNS';
$lang['WgsLinode.admin.tab.my_services.list.stackscript'] = 'Stackscript';
$lang['WgsLinode.admin.tab.my_services.list.swap_disk_id'] = 'swap Disk Id';