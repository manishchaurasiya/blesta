
// show hide password text
const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#reset_root_password');
			
togglePassword.addEventListener('click', function (e) {
	// toggle the type attribute
	const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
	password.setAttribute('type', type);

	// toggle the eye / eye slash icon
	//var toggleicon =$("#togglePassword");
	const icon = togglePassword.getAttribute('class') == 'fas fa-eye-slash' ? 'fas fa-eye' : 'fas fa-eye-slash';
	togglePassword.setAttribute('class', icon);
});
		
//copy to clipboard with tooltip
	function copyToClipboard(element) {
	  var $temp = $("<input>");
	  $("body").append($temp);
	  $temp.val($(element).text()).select();
	  document.execCommand("copy");
	  $temp.remove();
	  
	  $('#copybtn').tooltip({
		  trigger: 'click',
		  placement: 'bottom'
		});

	function setTooltip(btn, message) {
	  $(btn).tooltip('hide')
		.attr('data-original-title', message)
		.tooltip('show');
	}

	function hideTooltip(btn) {
	  setTimeout(function() {
		$(btn).tooltip('hide');
	  }, 1000);
	}
	var clipboard = new Clipboard('#copybtn');

	clipboard.on('success', function(e) {
	  setTooltip(e.trigger, 'Copied!');
	  hideTooltip(e.trigger);
	});  
}
		
		
// graph data 

Highcharts.getJSON(
  'https://cdn.jsdelivr.net/gh/highcharts/highcharts@v7.0.0/samples/data/usdeur.json',
  function (data) {

    Highcharts.chart('container', {
      chart: {
        zoomType: 'x'
      },
      title: {
        text: 'CPU Usage'
      },
      subtitle: {
        text: document.ontouchstart === undefined ?
          'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
      },
      xAxis: {
        type: ''
      },
      yAxis: {
        title: {
          text: 'Percentage'
        }
      },
      legend: {
        enabled: false
      },
      plotOptions: {
        area: {
          fillColor: {
            linearGradient: {
              x1: 0,
              y1: 0,
              x2: 0,
              y2: 1
            },
            stops: [
              [0, Highcharts.getOptions().colors[0]],
              [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
            ]
          },
          marker: {
            radius: 2
          },
          lineWidth: 1,
          states: {
            hover: {
              lineWidth: 1
            }
          },
          threshold: null
        }
      },

      series: [{
        type: 'area',
        name: 'USD to EUR',
        data: data
      }]
    });
  }
);		
		