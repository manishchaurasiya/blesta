// show hide password text
(() => {
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#reset_root_password');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);

        // toggle the eye / eye slash icon
        //var toggleicon =$("#togglePassword");
        const icon = togglePassword.getAttribute('class') == 'fas fa-eye-slash' ? 'fas fa-eye' : 'fas fa-eye-slash';
        togglePassword.setAttribute('class', icon);
    });
})()

//copy to clipboard with tooltip
function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();

    $('#copybtn').tooltip({
        trigger: 'click',
        placement: 'bottom'
    });

    function setTooltip(btn, message) {
        $(btn).tooltip('hide')
            .attr('data-original-title', message)
            .tooltip('show');
    }

    function hideTooltip(btn) {
        setTimeout(function () {
            $(btn).tooltip('hide');
        }, 1000);
    }
    var clipboard = new Clipboard('#copybtn');

    clipboard.on('success', function (e) {
        setTooltip(e.trigger, 'Copied!');
        hideTooltip(e.trigger);
    });
}

// make secure ajax calls
function secureCall(data = {}, action = window.location.href, method = "POST", dataType = 'json') {
    if (data._csrf_token === undefined && window._csrfToken !== undefined) {
        data._csrf_token = window._csrfToken
    }
    return new Promise((resolve, reject) => {
        $(this).blestaRequest(
            method, action, data, resolve, reject, dataType
        );
    })
}

$(document).ready(function () {
    //select 2 call
    $(".cdev").circlos();
    $('.select2').select2({
        templateResult: formatState
    });

    // ajax call on reboot button hit
    $('#reboot').click(async function () {
        try {
            $("#status").html("REBOOTING");
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> rebooting..');
            var response = await secureCall({ action: "reboot" })
            var responseData = JSON.parse(response);
            if (responseData.httpcode == 200) {
                Swal.fire(
                    '',
                    "server has been bebooted successfully!",
                    'success'
                )
            } else {
                Swal.fire(
                    '',
                    response.result.errors["0"].reasong,
                    'error'
                )
            }
        } catch (error) {
            console.log(error)
        } finally {
            $(this).html('<i class="fas fa-power-off">Reboot</i>');
        }
    });

    // ajax call on power on button hit
    $('#powerON').click(async function () {
        try {
            $("#status").html("BOOTING");
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> Booting..');
            var response = await secureCall({ action: "boot" })
            var responseData = JSON.parse(response);
            if (responseData.httpcode == 200) {
                Swal.fire(
                    '',
                    "Power on successfully",
                    'success'
                )
            } else {
                Swal.fire(
                    '',
                    response.result.errors["0"].reasong,
                    'error'
                )
            }
        } catch (error) {
            console.log(error)
        } finally {
            // stop loader
            $(this).html('<i class="far fa-play-circle">Power ON</i>');
        }
    });

    // ENABLE BACKUP    
    $('#enable').click(async function () {
        try {
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait...');
            var response = await secureCall({ action: "enable_backup" })
            var responseData = JSON.parse(response);
            if (responseData.status == 'success') {
                Swal.fire(
                    'Pending!',
                    responseData.msg,
                    'info'
                )
            } else {
                Swal.fire(
                    '',
                    responseData.msg,
                    'error'
                )
            }
        } catch (error) {
            console.log(error);
        } finally {
            $(this).html('<i class="fas fa-hdd">Enable Backup</i>');
        }
    });

    // disable backup 
    $("#cancle").click(function () {
        var result = Swal.fire({
            title: 'Are you sure?',
            text: "If you disable, you will have to pay again to enable backup!",
            icon: 'danger',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, disable backup!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait...');
                    var response = await secureCall({ action: "disable_backup" })
                    var responseData = JSON.parse(response);
                    if (responseData.httpcode == 200) {
                        Swal.fire(
                            'success!',
                            'Backup has been disable successfully!',
                            'success'
                        )
                    } else {
                        Swal.fire(
                            '',
                            response.result.errors["0"].reason,
                            'error'
                        )
                    }
                } catch (error) {
                    console.log(error);
                } finally {
                    $(this).html('<i class="fas fa-hdd">Cancle Backup</i>');
                }
            }
        });
    });

    // rebuild section 
    $("#rebuild").click(async function () {
        try {
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait...');
            var selectedImage = $('#rebuildselect :selected').val();
            var password = $(this).data("password");
            var response = await secureCall({ action: "rebuild", Image: selectedImage, password: password })
            var responseData = JSON.parse(response);
            if (responseData.httpcode == 200) {
                Swal.fire(
                    'success!',
                    'Rebuild successfully!',
                    'success'
                )
            } else {
                Swal.fire(
                    '',
                    responseData.result.errors["0"].reason,
                    'error'
                )
            }
        } catch (error) {
            console.log(error);
        } finally {
            $(this).html('<i class="fas fa-hdd">Rebuild</i>');
        }
    });

    // graph tab 
    // on change drop down
    $("#graph_select").change(async function () {
        // call onload graph function
        onloadGraph();
    });

    // on click of graph tabs
    $(".getData").click(async function () {
        try {
            $(".getData").removeClass("active");
            $(this).addClass("active");
            $("#container1").empty();
            $(".graph_spin").show();
            var id = $(this).attr("id");
            var graph_range = $("#graph_select").val();
            var response = await secureCall({ action: id, graph_range: graph_range });
            $('#container1').html(response);
        } catch (error) {
            console.log(error);
        } finally {
            $(".graph_spin").hide();
        }
    });

    // add ip address 
    $(".addIp").click(async function () {
        try {
            $(".addIp").removeClass("active");
            $(this).addClass("active");
            var id = $(".addIp.active").attr("id");
            // console.log(userAction.value);
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait..');
            var response = await secureCall({ action: id });
            var responseData = JSON.parse(response);
            if (responseData.httpcode == 200) {
                Swal.fire(
                    '',
                    'Ip address has been added successfully!',
                    'success'
                )
            } else {
                Swal.fire(
                    '',
                    responseData.result.errors["0"].reason,
                    'error'
                )
            }
        } catch (error) {
            console.log(error)
        } finally {
            if (id == "public_ip") {
                $(this).html('<i class="fas fa-plus-circle">Add Public IP</i>');
            } else {
                $(this).html('<i class="fas fa-plus-circle">Add Private IP</i>');
            }
        }
    });


    // take snapshot
    $("#takeSnapshot").click(function () {
        var result = Swal.fire({
            title: 'Are you sure?',
            text: "the previous snapshot will be deleted.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, take snapshot!'
        }).then((result) => {
            if (result.isConfirmed) {
                var userAction = Swal.fire({
                    title: 'Enter label for snapshot.',
                    input: 'text',
                    inputPlaceholder: 'Enter label here.',
                    inputValue: "",
                    showCancelButton: true,
                    inputValidator: (userAction) => {
                        if (!userAction) {
                            return 'You need to write something!'
                        }
                    }
                }).then(async (userAction) => {
                    if (userAction.isConfirmed) {
                        try {
                            var id = $(this).attr("id");
                            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait...');
                            var label = userAction.value;
                            var response = await secureCall({ action: id, label: label });
                            var responseData = JSON.parse(response);
                            // console.log(userAction.value);
                            if (responseData.httpcode == 200) {
                                Swal.fire(
                                    'Completed!',
                                    'Snapshot has been taken.',
                                    'success'
                                )
                            } else {
                                Swal.fire(
                                    '',
                                    responseData.result.errors["0"].reason,
                                    'error'
                                )
                            }
                        } catch (error) {
                            console.log(error);
                        } finally {
                            $(this).html('Take Snapshot');
                        }
                    }
                });
            }
        });
    });

    //reset root password

    $("#resetPassword").click(function () {
        var result = Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to change the password",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    var password = $('#reset_root_password').val();
                    console.log(password);
                    $("#resetPassword").html('<i class="fas fa-spinner fa-pulse"></i> wait...');
                    var response = await secureCall({ action: "resetRoorPassword", password: password });
                    var responseData = JSON.parse(response);
                    if (responseData.httpcode == 200) {
                        Swal.fire(
                            'Completed!',
                            'Root password has been changed successfully!',
                            'success'
                        )
                    } else {
                        Swal.fire(
                            '',
                            responseData.result.errors["0"].reason,
                            'error'
                        )
                    }
                } catch (error) {
                    console.log(error);
                } finally {
                    $("#resetPassword").html('<i class="fas fa-key">Reset Root Password</i>');
                }
            }
        });
    });
    // call onload graph function
    onloadGraph();


});

// restoreBackup 

async function restoreBackup(backupId) {
    try {
        $(".restorebackup").html('<i class="fas fa-spinner fa-pulse"></i>')
        var response = await secureCall({ action: "restoreBackup", backupId: backupId });
        // console.log(backupId);
        var responseData = JSON.parse(response);
        if (responseData.httpcode == 200) {
            Swal.fire(
                'Restored!',
                'Your has been restored!',
                'success'
            )
        } else {
            Swal.fire(
                '',
                responseData.result.errors["0"].reason,
                'error'
            )
        }
    } catch (error) {
        console.log(error);
    } finally {
        $(".restorebackup").html('<img src="https://blestamdev.shinedezign.pro/blesta/components/modules/wgs_linode/assets/images/server/server.svg" height="30px">')
    }
}


// delete ip address
function deleteIP(obj) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                $(obj).html('<i class="fas fa-spinner fa-pulse"></i>');
                var IpAddress = $(obj).data("ip");
                var response = await secureCall({ action: "delete_ip", Address: IpAddress });
                var responseData = JSON.parse(response);
                // console.log(responseData);
                if (responseData.httpcode == 200) {
                    Swal.fire(
                        'Deleted!',
                        'Your IP address has been deleted.',
                        'success'
                    )
                } else {
                    Swal.fire(
                        '',
                        responseData.result.errors["0"].reason,
                        'error'
                    )
                }
            } catch (error) {
                console.log(error);
            } finally {
                $(obj).html('<i class="fa fa-trash"></i>')
            }
        }
    })
}

// edit ips rdns
function editIpRdns(obj) {
    var rdns = $(obj).data("rdns");
    var userAction = Swal.fire({
        title: 'Enter your rDNS address',
        input: 'text',
        inputLabel: 'Your IP address',
        inputValue: rdns,
        showCancelButton: true,
        inputValidator: (userAction) => {
            if (!userAction) {
                return 'You need to write something!'
            }
        }
    }).then(async (userAction) => {
        if (userAction.isConfirmed) {
            try {
                $(obj).html('<i class="fas fa-spinner fa-pulse"></i>');
                var IpAddress = $(obj).data("ip");
                // edited rdns
                // console.log(userAction.value);
                var response = await secureCall({ action: "edit_ip", address: IpAddress, rDNS: userAction.value });
                var responseData = JSON.parse(response);
                if (responseData.httpcode == 200) {
                    Swal.fire(
                        'Edited!',
                        'Your IP address has been Edited successfully.',
                        'success'
                    )
                } else {
                    Swal.fire(
                        '',
                        responseData.result.errors["0"].reason,
                        'error'
                    )
                }
            } catch (errro) {
                console.log(error);
            } finally {
                $(obj).html('<i class="fas fa-edit"></i>')
            }
        }
    })
}

//search in select 2 data
function formatState($linode_type) {
    if ($linode_type) {
        return $linode_type.text;
    }
}


// on page load load graph
async function onloadGraph() {
    try {
        $("#container1").empty();
        $(".graph_spin").show();
        var id = $(".getData.active").attr("id");
        var graph_range = $("#graph_select").val();
        var response = await secureCall({ action: id, graph_range: graph_range });
        $('#container1').html(response);
    } catch (error) {
        console.log(error);
    } finally {
        $(".graph_spin").hide();
    }
}
