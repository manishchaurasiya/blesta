<?php

use Blesta\Core\Util\Input\Fields\InputFields;

class Admin extends WgsLinodeController
{
    public $errors = [], $success = [], $warnings = [];
    public function preAction()
    {
        parent::preAction();
        if (!$this->PluginManager->isInstalled('wgs_linode', $this->company_id)) {
            $this->redirect($this->client_uri);
        }
        $this->structure->set('page_title', Language::_('Admin.index.page_title', true));
        $this->requireLogin();
        Loader::loadComponents($this, ['Session', 'Input', 'Record']);
        $this->uses(["WgsLinode.WgsLinodeLicense", 'Companies']);
        // Restore structure view l0ocati.on of the admin portal
        $this->structure->setDefaultView(APPDIR);
        $this->view_url = Router::makeURI(str_replace('index.php/', '', WEBDIR) . $this->view->view_path . "assets/");
        $this->set("view_url", $this->view_url);
        Language::loadLang('wgs_linode_admin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        // Set the page title
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.index.page_title', true));
        $this->structure->set('head', $this->getDefaultCss());
        // head
    }

    public function dashboard()
    {
        // Set View
        $this->view->setView('dashboard', 'wgs_linode.admin');
        // Get license key and validation starts
        $license_key = $this->WgsLinodeLicense->getLicenseKey(Configure::get('Blesta.company_id'));

        // print_r($license_key);
        if (($errors = $this->WgsLinodeLicense->errors())) {
            $this->set('error', $errors);
        } else {
            $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($license_key, Configure::get('Blesta.company_id'));
            // Set errors, if any
            // print_r($licenseInfo);
            if (($errors = $this->WgsLinodeLicense->errors())) {
                $this->set('error', $errors);
            } else {
                // Handle License validation response
                if ($licenseInfo["status"] != "active") {
                    // $this->set('error', ['error'=> ['license'=>Language::_('WgsLinodeAdmin.!error.license.valid', true)]]);
                }
                $this->set('licenseInfo', $licenseInfo);
            }
        }
        // Get license key and validation ends
        // Return view to be displayed
        return $this->view->fetch();
    }

    public function productSettings()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeLicense', 'WgsLinode.WgsLinodeHelper', 'ModuleManager', 'WgsLinode.WgsLinodeApi', 'Companies']);
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        //  get linode plans
        $linodePlans = $this->WgsLinodeApi->getTypes();
        foreach ($linodePlans["result"]->data as $key => $value) {
            $linode_type[$value->id] = $value->label;
        }
        //  get kernals

        $kernals = $this->WgsLinodeApi->getKernels();
        foreach ($kernals["result"]->data as $key => $value) {
            $kernal[$value->id] = $value->label;
        }

        // update product setting
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.product_settings.page_title', true));

        if (count($this->post)) {
            $status = isset($this->post["status"]) ? "1" : "0";
            $stack_script = isset($this->post["stack_script"]) ? "1" : "0";

            $data = [
                "company_id" => Configure::get('Blesta.company_id'),
                "product_id" => $_POST['product_id'],
                "linode_plan" => $_POST['linode_plan'],
                "kernel" => $_POST['kernel'],
                "subscription" => $_POST['subscription'],
                "swap" => $_POST['swap'],
                "stack_script" => $stack_script,
                "status" => $status
            ];
            $this->WgsLinodeHelper->updateProductSetting($data);

            if ($this->WgsLinodeHelper->errors()) {
                $this->set('error', $this->WgsLinodeHelper->errors());
            } else {
                $this->set('success', ['success' => ['image' => Language::_('WgsLinodeAdmin.!success.product.setting', true)]]);
            }
        }

        $moduleDetails = $this->ModuleManager->getByClass("wgs_linode", Configure::get('Blesta.company_id'));
        $products = [];
        if (isset($moduleDetails[0]->id)) {
            $products = $this->WgsLinodeHelper->getProductsByModule($moduleDetails[0]->id);
        } else {
            $this->set('notice', ['notice' => ['notice' => Language::_('WgsLinodeAdmin.!error.module', true)]]);
        }
        // set jquery to the head
        // $view_url = Router::makeURI(str_replace('index.php/', '', WEBDIR) . $this->view->view_path . "assets/");
        $this->Javascript->setFile('js/jquery.dataTables.min.js', 'head', $this->view_url);
        $this->Javascript->setFile('js/select2.min.js', 'head', $this->view_url);

        $this->view->setView('product_setting', 'wgs_linode.admin');
        $this->set(compact("products", "linode_type", "kernal"));
        return $this->view->fetch();
    }

    public function editProductSetting()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeLicense', 'WgsLinode.WgsLinodeHelper']);
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.product_features.page_title', true));

        $featureList = $this->WgsLinodeHelper->linodeProductFeatures;

        if (count($this->post)) {
            // save features
            $pid = (isset($this->post["product_id"]) ? $this->post["product_id"] : false);
            $company_id = Configure::get('Blesta.company_id');
            $activeFeatures = [];
            foreach ($featureList as $key => $value) {
                $activeFeatures[$value] = (isset($this->post['feature'][$value]) ? '1' : '0');
            }
            $activeFeatures = json_encode($activeFeatures);
            $this->WgsLinodeHelper->updateFeatures($company_id, $pid, $activeFeatures);
            if ($this->WgsLinodeHelper->errors()) {
                $this->set('error', $this->WgsLinodeHelper->errors());
            } else {
                $this->set('success', ['success' => ['image' => Language::_('WgsLinodeAdmin.!success.features', true)]]);
            }
        }

        $productFatures = $this->WgsLinodeHelper->getFeatures($_GET['pid']);
        if (!empty($productFatures)) {
            $features = json_decode($productFatures->feature, true);
        }

        $enabledFeatures = [];
        foreach ($featureList as $key => $value) {
            $enabledFeatures[$value] = (isset($features[$value]) && $features[$value] == '1' ? true : false);
        }

        $this->set(compact("featureList", "enabledFeatures"));
        $this->view->setView('edit_product_setting', 'wgs_linode.admin');
        return $this->view->fetch();
    }

    public function assignExistingServer()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeLicense', 'WgsLinode.WgsLinodeHelper', 'WgsLinode.WgsLinodeApi', 'Clients', 'ModuleManager', 'GatewayManager', 'Services', 'Invoices', "Packages"]);
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.assign_existing_server.page_title', true));
        //get products
        $moduleDetails = $this->ModuleManager->getByClass("wgs_linode", Configure::get('Blesta.company_id'));
        $products = [];
        if (isset($moduleDetails[0]->id)) {
            foreach ($this->WgsLinodeHelper->getProductsByModule($moduleDetails[0]->id) as $key => $product) {
                $products[$product->id] = $product->name;
            }
        } else {
            // set error that module is not active
        }
        //get clients 
        $clientdetail = $this->Clients->getAll();
        $clients = [];
        if (isset($clientdetail[0]->id)) {
            foreach ($clientdetail as $key => $client) {
                $clients[$client->id] = $client->first_name . " " . $client->last_name;
            }
        } else {
            // set error that module is not active
        }
        // get all gateways
        $allGateways = $this->GatewayManager->getInstalled();
        $gateways = [];
        if (isset($allGateways[0]->id)) {
            foreach ($allGateways as $key => $gateway) {
                $gateways[$gateway->id] = $gateway->name;
            }
        } else {
            // set error that module is not active
        }
        // get active server
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $activeServer = $this->WgsLinodeApi->getActiveServer();
        $linodeActiveServer = $this->WgsLinodeHelper->getActiveServerName($activeServer);

        //ajax handle 
        // assign existing services 
        if (!empty($_POST) && isset($_POST)) {
            // assign new services
            if ($_POST["action"]  == "assign_new") {
                //get pricing id from package_pricing table
                $pricingDetail = $this->WgsLinodeHelper->getData("package_pricing", ["package_id" => $_POST["products"]]);
                $pricingId = $pricingDetail->id;
                $serviceData = [
                    "pricing_id" => $pricingId,
                    "client_id" => $_POST["clients"],
                    "status" => isset($_POST["create_invoice"] ) ? 'pending' : "active",
                    "suspension_reason" => NULL,
                    "use_module" => isset($_POST["create_invoice"] ) ? 'true' : 'false'
                ];
                $send_email = (isset($_POST["send_email"]) ? true : false);
                $linodeServerDetail = $this->WgsLinodeApi->getseverdetails($_POST["linode_server"]);
                $updateServicefields = [
                    [
                        "key" => "linode_id",
                        "value" => $_POST["linode_server"],
                        "encrypted" => false
                    ],
                    [
                        "key" => "linode_label",
                        "value" => $linodeServerDetail["result"]->label,
                        "encrypted" => false
                    ],
                    [
                        "key" => "main_disk_id",
                        "value" => "",
                        "encrypted" => false
                    ],
                    [
                        "key" => "password",
                        "value" => "",
                        "encrypted" => false
                    ],
                    [
                        "key" => "resoucres_id",
                        "value" => "",
                        "encrypted" => false
                    ],
                    [
                        "key" => "reverse_dns",
                        "value" => "",
                        "encrypted" => false
                    ],
                    [
                        "key" => "stackscript",
                        "value" => "",
                        "encrypted" => false
                    ],
                    [
                        "key" => "swap_disk_id",
                        "value" => "",
                        "encrypted" => false
                    ],
                ];
                $serviceId =  $this->Services->add($serviceData, null, $send_email);
                // update service fields table 
                $this->Services->setFields($serviceId, $updateServicefields);
                if (isset($_POST["create_invoice"]) && $serviceId) {
                    // package details
                    $packageDetails = $this->Packages->get($_POST["products"]);
                    $packagePrice = $packageDetails->pricing["0"]->price;
                    $linodeId = $_POST["linode_server"];
                    $invoiceData = $this->WgsLinodeHelper->serviceInvoice($_POST["clients"], $serviceId, $packagePrice, $_POST["billing_cycle"]);
                    $status = $this->Invoices->add($invoiceData);
                    $msg =  "Service created succefully!";
                    echo json_encode(["status" => "success", "msg" => $msg]);
                    // echo json_encode($this->Invoices->errors());
                    exit();
                }
                $msg =  "Service created succefully!";
                echo json_encode(["status" => "success", "msg" => $msg]);
                echo json_encode($this->Services->errors());
                exit();
            } elseif ($_POST["action"]  == "assign_existing") {
                $updateData = [
                    "key" => "linode_id",
                    "value" => $_POST["Linode_Sever"],
                    "encrypted" => false
                ];
                $updatedLinode = $this->Services->editField((int)$_POST["Existing_Service"], $updateData);
                if (empty($updatedLinode)) {
                    $msg = "Server assign succefully!";
                    echo json_encode(["status" => "success", "msg" => $msg]);
                    exit();
                } else {
                    $msg = "There is some problem!";
                    echo json_encode(["status" => "error", "msg" => $msg]);
                    exit();
                }
            } elseif ($_POST["action"]  == "onClientChange") {
                $serviceDetail =  $this->Services->getAllByClient($_POST["clientId"], 'active', ['date_added' => 'DESC'], true, null);
                $services = [];
                foreach ($serviceDetail as $key => $value) {
                    $services[$value->id] = $value->package->name;
                }
                echo json_encode($services);
                exit();
            }
        }
        $this->Javascript->setFile('js/script.js', 'head', $this->view_url);
        $this->set(compact("clients", "products", "gateways", "linodeActiveServer"));

        $this->view->setView('assign_existing_server', 'wgs_linode.admin');
        return $this->view->fetch();
    }

    public function stackScript()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeHelper', 'WgsLinode.WgsLinodeApi']);
        //set page title
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.stack_script.page_title', true));
        //update linode_stackscripts table
        $this->WgsLinodeHelper->updateApiData();
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        // update public status
        if (count($this->post) && isset($_POST["is_public"])) {
            $data = ["is_public" => true];
            $response = $this->WgsLinodeApi->updateScript($_POST["scriptid"], $data);
            if ($response["httpcode"] == 200) {
                $this->Record->where("scriptid", "=", $_POST["scriptid"])->update("linode_stackscripts", ["is_public" => 1]);
            }

            // set error if any
            if ($this->WgsLinodeApi->errors()) {
                $this->set('error', $this->WgsLinodeApi->errors());
            } else {
                $this->set('success', ['success' => ['is_public' => Language::_('WgsLinodeAdmin.!success.stack_script.is_public', true)]]);
            }
        }
        // delete 
        if (isset($_POST["delete"])) {
            $response = $this->WgsLinodeApi->deleteScript($_POST["scriptid"]);
            $this->Record->from("linode_stackscripts")->where("scriptid", "=",  $_POST['scriptid'])->delete();

            // set error if any
            if ($this->WgsLinodeApi->errors()) {
                $this->set('error', $this->WgsLinodeApi->errors());
            } else {
                $this->set('success', ['success' => ['delete' => Language::_('WgsLinodeAdmin.!success.stack_script.delete', true)]]);
            }
        }

        $this->Javascript->setFile('js/jquery.dataTables.min.js', 'head', $this->view_url);
        //get data from linode_stackscripts table
        $records = $this->WgsLinodeHelper->getData("linode_stackscripts", [], true);
        // get user name
        $userName = $this->WgsLinodeHelper->getCompanySettingValue("wgs_linode_username");
        $this->view->setView('stack_script', 'wgs_linode.admin');
        $this->set(compact("records", "userName"));
        return $this->view->fetch();
    }


    public function createStackscript()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeHelper', 'WgsLinode.WgsLinodeApi']);
        //set page title
        $this->structure->set('page_title', Language::_('WgsLinodeAdmin.stack_script.page_title', true));

        //get server images
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $images = $this->WgsLinodeApi->getImages();
        foreach ($images["result"]->data as $key => $value) {
            $serverImages[$value->id] = $value->label;
        }

        // create stack script
        if (count($this->post) && (!isset($_GET['scriptid']))) {
            $data = ['description' => $_POST["description"], 'images' => $_POST["states"],  "is_public" => false, 'label' => $_POST["stackscript_label"], 'rev_note' => $_POST["revision"], 'script' => $_POST["script"]];
            $response = $this->WgsLinodeApi->createScript($data);
            if ($response["httpcode"] != "200" || (isset($response["result"]->error))) {
                $this->set('error', Language::_('WgsLinodeAdmin.!error.linode.server.api_token_not_working', true));
            }
            //  insert data in linode_stackscripts table 
            if ($response["httpcode"] == 200) {
                $images = implode(",", $response["result"]->images);
                $stackScriptTableData = [
                    "company_id" => Configure::get('Blesta.company_id'),
                    "scriptid" => $response["result"]->id,
                    "label" => $response["result"]->label,
                    "description" => $response["result"]->description,
                    "script" => $response["result"]->script,
                    "revision" => $response["result"]->rev_note,
                    "images" => $images,
                    "deployments_active" => "0",
                    "is_public" => (empty($response["result"]->is_public) ? "0" : "1")
                ];
                $this->Record->insert("linode_stackscripts", $stackScriptTableData);
            }
        }

        // update stackScript 
        if (isset($_GET['scriptid']) && !empty($_GET['scriptid'])) {
            $data  = $this->WgsLinodeHelper->getData("linode_stackscripts", ["scriptid" => $_GET['scriptid']], false);
            // check save button hit
            if (count($this->post)) {
                $formData = ['description' => $_POST["description"], 'images' => $_POST["states"], 'label' => $_POST["stackscript_label"], 'rev_note' => $_POST["revision"], 'script' => $_POST["script"]];
                // update api hit
                $responce = $this->WgsLinodeApi->updateScript($data->scriptid, $formData);
                if (isset($responce["httpcode"]) && $responce["httpcode"] == 200) {
                    // update data in linode_stackScript table
                    $images = implode(",", $_POST["states"]);
                    $this->Record->where("scriptid", "=", $data->scriptid)->update("linode_stackscripts", ["label" => $_POST["stackscript_label"],  "description" => $_POST["description"], "script" => $_POST["script"],  "images" => $images,  "revision" => $_POST["revision"]]);
                    // set error if any
                } else {
                    $errors =  Language::_('WgsLinodeAdmin.!error.linode.server.api_token_not_working', true);
                    $this->set('error', $errors);
                    // return false;
                }
            }
            $this->set(compact("data"));
        }

        Language::loadLang('wgs_linode_admin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        $view_url = Router::makeURI(str_replace('index.php/', '', WEBDIR) . $this->view->view_path . "assets/");
        $this->Javascript->setFile('js/jquery.validate.min.js', 'head', $view_url);

        $this->view->setView('create_stackscript', 'wgs_linode.admin');
        $this->set(compact("serverImages"));
        return $this->view->fetch();
    }

    public function getDefaultCss()
    {
        $cssFiles = [
            $this->base_url . $this->view_url . 'css/header.css',
            $this->base_url . $this->view_url . 'css/datatable.css',
            $this->base_url . $this->view_url . 'css/select2.min.css',
            $this->base_url . $this->view_url . 'css/bootstrap.min.css',
            $this->base_url . $this->view_url . 'css/style.css',
        ];
        ob_start();
        if (count($cssFiles)) :
            foreach ($cssFiles as $key => $css) :
                echo "<link rel='stylesheet' href='$css'>";
            endforeach;
        endif;
        $contents = ob_get_contents();
        ob_end_clean();
        return $contents;
    }
}
