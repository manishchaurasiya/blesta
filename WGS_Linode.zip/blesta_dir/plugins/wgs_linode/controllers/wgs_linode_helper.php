<?php

use Blesta\Core\Util\Input\Fields\InputFields;

/**
 * 
 *
 * Manages License information for WGS Linode
 *
 * @package WgsLinodeC
 * @subpackage blesta.plugins.wgs_linode_plugin.models
 * @copyright Copyright (c) WHMC
 * @license https://whmcsglobalservices.com/license The Blesta License Agreement
 * @link https://whmcsglobalservices.com/ Whmcs Global Services
 */
class WgsLinodeHelper extends WgsLinodeModel
{
    public function __construct()
    {
        parent::__construct();
        Loader::loadComponents($this, ['Input', 'Record']);
        Language::loadLang('wgs_linode_plugin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        Language::loadLang('wgs_linode_admin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
    }
    /**
     * Fetches the given package
     *
     * @param int $package_id The package ID to fetch
     * @return mixed A stdClass object representing the package, false if no such package exists
     */
    public function getProductsByModule($module_id)
    {
        $result = $this->Record->select($this->getSelectFieldList())->from('packages')->on('package_names.lang', '=', Configure::get('Blesta.language'))->leftJoin('package_names', 'package_names.package_id', '=', 'packages.id', false)->leftJoin('linode_product_setting', 'linode_product_setting.product_id', '=', 'packages.id', false)->where('module_id', '=', $module_id)->fetchAll();

        foreach ($result as $key => $value) {
            $features = [];
            $activeFeatures = [];
            $data = $this->getData("linode_features", ["product_id" => $value->id, "company_id" => Configure::get('Blesta.company_id')]);
            if (isset($data->feature) && !empty($data->feature)) {
                $features = json_decode($data->feature, true);
                foreach ($features as $featurekey => $isEnabled) {
                    if ($isEnabled) {
                        $activeFeatures[$featurekey] = true;
                    }
                }
            }
            $result[$key]->activeFeatures = $activeFeatures;
            $result[$key]->features = $features;
        }
        return $result;
    }

    /**
     * Gets a list a fields to fetch for packages
     *
     * @return array A list a fields to fetch for packages
     */
    private function getSelectFieldList()
    {
        return [
            'packages.id',
            'packages.id_format',
            'packages.id_value',
            'packages.module_id',
            'package_names.name' => 'name',
            'packages.qty',
            'packages.client_qty',
            'packages.module_row',
            'packages.module_group',
            'packages.taxable',
            'packages.single_term',
            'packages.status',
            'packages.hidden',
            'packages.company_id',
            'packages.prorata_day',
            'packages.prorata_cutoff',
            'packages.upgrades_use_renewal',
            'linode_product_setting.company_id',
            'linode_product_setting.product_id',
            'linode_product_setting.linode_plan',
            'linode_product_setting.kernel',
            'linode_product_setting.subscription',
            'linode_product_setting.swap',
            'linode_product_setting.stack_script',
            'linode_product_setting.status'
        ];
    }

    // ------   save or update product setting -------------------

    public function updateProductSetting($data)
    {
        Loader::loadModels($this, ['Companies', 'PackageOptionGroups', 'PackageOptions', 'ModuleManager']);

        $result = false;
        $packageStatus = $this->Record->select(['status'])->from('packages')->where("id", "=", $data["product_id"])->fetch();
        $productData = $this->Record->select()->from('linode_product_setting')->where("product_id", "=", $data["product_id"])->fetch();
        if (empty($productData)) {
            $result = $this->Record->insert('linode_product_setting', $data);

            //update packages status
            $status = $data["status"] == 0 ? "inactive" : "active";
            $this->Record->where("id", "=", $data["product_id"])->update("packages", ["status" => $status]);
        } else {
            $result = $this->Record->where("product_id", "=", $data["product_id"])->update('linode_product_setting', $data);

            //update packages status
            $status = $data["status"] == 0 ? "inactive" : "active";
            $this->Record->where("id", "=", $data["product_id"])->update("packages", ["status" => $status]);
        }

        if (!$result) {
            $this->Input->setErrors('error', ['error' => ['license' => Language::_('WgsLinodeAdmin.!error.product.setting', true)]]);
            return;
        }

        // get product ids
        $option_group_id = $this->getCompanySettingValue("wgs_linode_package_option_group");
        $productIDs = $this->Record->select(["product_id"])->from('linode_product_setting')->fetchAll();
        $productID = [];
        foreach ($productIDs as $key => $value) {
            $productID[$value->product_id] = $value->product_id;
        }
        // edit product group 
        $this->PackageOptionGroups->edit($option_group_id, ["name" => 'WGS Linode', "description" => "WGS Linode product config option", "packages" => $productID]);

        return $result;
    }

    // ------   save or update product features -------------------

    public function updateFeatures($company_id, $product_id, $feature)
    {
        $result = false;
        $productData = $this->Record->select()->from('linode_features')->where("product_id", "=", $product_id)->fetch();
        if (empty($productData)) {
            $result = $this->Record->set("company_id", $company_id)->set("product_id", $product_id)->set("feature", $feature)->insert('linode_features');
        } else {
            $result = $this->Record->where("product_id", "=", $product_id)->update('linode_features', ["feature" => $feature]);
        }

        if (!$result) {
            $this->Input->setErrors('error', ['error' => ['license' => Language::_('WgsLinodeAdmin.!error.features', true)]]);
            return;
        }
        return $result;
    }

    // ------   get product features -------------------

    public function getFeatures($product_id = false)
    {
        return $this->Record->select()->from('linode_features')->where("product_id", "=", $product_id)->fetch();
    }

    public function getData($tableName, $conditions = [], $isAll = false)
    {
        $result = $this->Record->select()->from($tableName);
        foreach ($conditions as $key => $value) {
            $result->where($key, "=", $value);
        }

        if ($isAll) {
            $result = $result->fetchAll();
        } else {
            $result = $result->fetch();
        }
        return $result;
    }

    public function getModuleClassByPricingId($package_pricing_id)
    {
        return $this->Record->select(['modules.*', 'packages.id' => 'package_id'])->from('package_pricing')->innerJoin('packages', 'packages.id', '=', 'package_pricing.package_id', false)->innerJoin('modules', 'modules.id', '=', 'packages.module_id', false)->where('package_pricing.id', '=', $package_pricing_id)->fetch();
    }

    // check product enable or not
    public function isProductEnabled($package_id)
    {
        // getting "stack_script" to check stack_script status is enabled or not 
        $productInfo = $this->Record->select(['status', 'stack_script'])->from('linode_product_setting')->where("product_id", "=", $package_id)->fetch();
        return (isset($productInfo->status) ? $productInfo->status : false);
    }


    public function createConfigOptions()
    {
        try {
            Loader::loadModels($this, ['Companies', 'PackageOptionGroups', 'PackageOptions', 'ModuleManager']);
            // create  packageOPtionGroup
            $packageConfigOptionGroup = false;

            // Create Config Option group if does not exist
            if (empty($packageConfigOptionGroup = $this->getCompanySettingValue("wgs_linode_package_option_group"))) {
                $packageConfigOptionGroup = $this->PackageOptionGroups->add([
                    "company_id" => Configure::get('Blesta.company_id'),
                    "name" => 'WGS Linode',
                    "description" => "WGS Linode Configuration Options",
                ]);

                // Check if any error occured while creating package option group else save group id
                if (($errors = $this->PackageOptionGroups->errors())) {
                    $this->Input->setErrors($errors);
                    return;
                } else {
                    // if (array_key_exists($regions->id, $this->datacenter)) {

                    $this->Companies->setSetting(Configure::get('Blesta.company_id'), "wgs_linode_package_option_group", $packageConfigOptionGroup);
                    // set and return error if company setting does not save
                    if (($errors = $this->Companies->errors())) {
                        $this->Input->setErrors($errors);
                        return;
                    }
                }
            }

            foreach ($this->getPackageConfigOptions() as $key => $getPackageConfigOption) {
                $getPackageConfigOption["groups"]["option_group_id"] = $packageConfigOptionGroup;

                if (!$this->checkPackageOptionExist($getPackageConfigOption["name"])) {
                    $this->PackageOptions->add($getPackageConfigOption);
                    if (($errors = $this->PackageOptions->errors())) {
                        $this->Input->setErrors($errors);
                        return;
                    }
                }
            }
        } catch (\Exception $error) {
            $this->Input->setErrors('error', ['error' => ['error' => $error->getMessage()]]);
            return;
        }
    }

    public function getCompanySettingValue($option_key = false)
    {
        try {
            Loader::loadModels($this, ['Companies']);
            $result = $this->Companies->getSetting(Configure::get('Blesta.company_id'), $option_key);
            return (isset($result->value) ? $result->value : false);
        } catch (\Exception $error) {
            $this->Input->setErrors('error', ['error' => ['error' => $error->getMessage()]]);
            return;
        }
    }

    public function getPackageConfigOptions()
    {
        return $packageConfigOptions = [
            [
                "company_id" => Configure::get('Blesta.company_id'),
                "label" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.label.private_ip', true),
                "name" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.name.wgs_linode_private_ip', true),
                "type" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.type.checkbox', true),
                "addable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.addable', true),
                "editable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.editable', true),
                "values" => [
                    [
                        "name" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.name', true),
                        "value" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.value', true),
                        "default" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.default', true),
                        "status" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.status', true),
                        "pricing" => [
                            [
                                "term" => Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.term', true),
                                "period" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.period', true),
                                "price" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.price', true),
                            ]
                        ]
                    ]
                ]
            ],
            [
                "company_id" => Configure::get('Blesta.company_id'),
                "label" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.label.backup', true),
                "name" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.name.wgs_linode_backup', true),
                "type" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.type.checkbox', true),
                "addable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.addable', true),
                "editable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.editable', true),
                "values" => [
                    [
                        "name" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.name', true),
                        "value" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.value', true),
                        "default" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.default', true),
                        "status" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.status', true),
                        "pricing" => [
                            [
                                "term" => Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.term', true),
                                "period" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.period', true),
                                "price" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.price', true),
                            ]
                        ]
                    ]
                ]
            ]
        ];
    }


    public function checkPackageOptionGroupsExist($company_id, $name)
    {
        return $this->Record->select(["id"])->from('package_option_groups')->where("company_id", "=", $company_id)->where("name", "=", $name)->fetch();
    }

    public function checkPackageOptionExist($option_name)
    {
        return $this->Record->select()->from('package_options')->where("company_id", "=", Configure::get('Blesta.company_id'))->where("name", "=", $option_name)->fetch();
    }

    public function getConfigSetting()
    {
        $settings = [];
        foreach ($this->settings as $key => $value) {
            $settings[$key] =  $this->Companies->getSetting(Configure::get('Blesta.company_id'), $key);
        }
        return $settings;
    }

    private function configureApiParams()
    {
        if (!isset($this->WgsLinodeApi)) {
            Loader::loadModels($this, ['WgsLinode.WgsLinodeApi']);
        }

        $wgsLinodeConfigSetting = $this->getConfigSetting();
        $this->WgsLinodeApi->setParams($wgsLinodeConfigSetting['wgs_linode_api_url']->value, $wgsLinodeConfigSetting['wgs_linode_api_key']->value);
    }

    public function getApiCustomFields()
    {
        $this->configureApiParams();

        $result = [
            "server_image" => [],
            "datacenter" => [],
            "stackscript" => []
        ];

        $datacenterRegions = $this->WgsLinodeApi->getRegions();
        if ($datacenterRegions["httpcode"] == 200) {
            foreach ($datacenterRegions["result"]->data as $regions) {
                if (array_key_exists($regions->id, $this->datacenter)) {
                    $result["datacenter"][$regions->id] =  $this->datacenter[$regions->id];
                }
            }
        }

        // get distribution images 
        $serverImage = $this->WgsLinodeApi->getDistibutionImages();
        if ($serverImage["httpcode"] == 200) {
            foreach ($serverImage['result']->data as $key => $serverImage) {
                $result["server_image"][$serverImage->id] = $serverImage->label;
            }
        }

        // stackScript 
        $stackScript = $this->WgsLinodeApi->getScript();
        if ($stackScript["httpcode"] == 200) {
            foreach ($stackScript['result']->data as $key => $stackScripts) {
                $result["stackscript"][$stackScripts->id] = $stackScripts->label;
            }
        }
        foreach ($result as $key => $value) {
            if (!isset($this->customFields[$key])) {
                unset($result[$key]);
            }
        }

        return $result;
    }

    public function generateModuleFields($params, array $vars, $moduleFieldType = 'meta')
    {
        Loader::loadHelpers($this, ['Html']);
        // get meta data fom local table 
        $images = $this->Record->select(["images"])->from("linode_stackscripts")->where("scriptid", "=", $vars["stackscript"])->fetch();
        $image = explode(",", $images->images);

        $filters = new InputFields();

        foreach ($params as $key => $param) {
            if ($param["type"] == "text") {
                // Create text label
                $field = $filters->label($param["label"], $key);
                // Create "filters[field]" input field
                $field->attach(
                    $filters->fieldText(
                        $moduleFieldType . '[' . $key . ']',
                        isset($vars[$key]) ? $vars[$key] :  $this->Html->ifSet($param["value"]), // Pre-populate the field if it is defined in $vars
                        [
                            'id' => $key,
                            'class' => 'form-control',
                            'placeholder' => $param["label"]
                        ]
                    )
                );
                $filters->setField($field);
            } elseif ($param["type"] == "select") {
                // Create label
                $field = $filters->label($param["label"], $key);
                // Create "filters[]" select field
                //check script images assign or not
                if (isset($vars["stackscript"]) && !empty($vars["stackscript"] && $key == "server_image")) {
                    $field->attach(
                        $filters->fieldSelect(
                            $moduleFieldType . '[' . $key . ']',
                            $image,
                            isset($vars[$key]) ? $vars[$key] : null,
                            ['id' => $key, 'class' => 'form-control']
                        )
                    );
                    $filters->setField($field);
                } else {
                    $field->attach(
                        $filters->fieldSelect(
                            $moduleFieldType . '[' . $key . ']',
                            (isset($param["value"]) ? $param["value"] : []),
                            isset($vars[$key]) ? $vars[$key] : null,
                            ['id' => $key, 'class' => 'form-control']
                        )
                    );
                    $filters->setField($field);
                }
            }
        }

        // You can set HTML code as well!
        // $filters->setHtml('
        //     <script type="text/javascript">alert("It Works!");</script>
        // ');

        return $filters;
    }

    // update api data in database table linode_stackscripts
    public function updateApiData()
    {
        $this->configureApiParams();

        // Get local stack scripts from database
        $getLocalStackScripts = $this->Record->select()->from("linode_stackscripts")->fetchAll();
        $localStackScripts = [];
        foreach ($getLocalStackScripts as $key => $value) {
            $localStackScripts[$value->scriptid] = (array)$value;
        }
        $syncedStackScripts = $localStackScripts;
        $getApiStackScripts = $this->WgsLinodeApi->getScript();
        if (isset($getApiStackScripts["httpcode"]) && $getApiStackScripts["httpcode"] == 200 && isset($getApiStackScripts["result"]->data)) {
            // get script data
            $apiScriptData = [];
            $apiScriptDataIds = [];
            foreach ($getApiStackScripts["result"]->data as $key => $value) {
                $apiScriptData[$value->id] = $value;
                $apiScriptDataIds[$value->id] = $value->id;
                $syncedStackScripts[$value->id] = [
                    'id' => false,
                    'company_id' => Configure::get('Blesta.company_id'),
                    'scriptid' => $value->id,
                    'label' => $value->label,
                    'description' => $value->description,
                    'script' => $value->script,
                    'revision' => $value->rev_note,
                    'images' => implode(',', $value->images),
                    'deployments_active' => $value->deployments_active,
                    'is_public' => (isset($value->is_public) ? (int)$value->is_public : 0),
                    'is_found' => true
                ];

                if (isset($localStackScripts[$value->id])) {
                    $syncedStackScripts[$value->id]["id"] = $localStackScripts[$value->id]["id"];
                    unset($localStackScripts[$value->id]);
                }
            }

            foreach ($syncedStackScripts as $key => $script) {
                if (isset($script["is_found"])) {
                    unset($script["is_found"]);
                    if ($script["id"]) {
                        // update here
                        $this->Record->where("scriptid", "=", $script["scriptid"])->update("linode_stackscripts", $script);
                    } else {
                        // insert here
                        unset($script["id"]);
                        $this->Record->insert("linode_stackscripts", $script);
                    }
                } else {
                    // remove this script
                    $this->Record->from("linode_stackscripts")->where("scriptid", "=", $script["scriptid"])->delete();
                }
            }


            return true;
        }
        $this->Input->setErrors('error', ['error' => ['error' => Language::_('WgsLinodeAdmin.!error.sync_api_data_with_database', true)]]);
        return false;
    }

    // get datacenter region

    public function getDataCenterRegion($regionId)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig']);
        if (array_key_exists($regionId, $this->WgsLinodeConfig->datacenter)) {
            return $this->WgsLinodeConfig->datacenter[$regionId];
        }
    }

    // reset root password 
    public function resetRootPassword($newPassword, $linodeId, $status, $package_id)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeApi']);
        $settings = $this->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        if ($status != "offline") {
            $resposnce = $this->WgsLinodeApi->serverShutDown($linodeId);
            while ($this->WgsLinodeApi->getseverdetails($linodeId)["result"]->status == 'shutting_down') {
                sleep(1);
            }
            if ($resposnce["httpcode"] == 200) {
                $resposnce = $this->WgsLinodeApi->resetRootPassword($linodeId);
                echo"<pre>";
                print_r($resposnce);
                // update password in package_meta table
                $this->Record->where("package_id", "=", $package_id)->where("key", "=", "password")->update("package_meta", ["value" => $newPassword]);
            } else {
                // set error here
            }
        }
        //rebooting server
        $this->WgsLinodeApi->serverReeBoot($linodeId);
    }

}
