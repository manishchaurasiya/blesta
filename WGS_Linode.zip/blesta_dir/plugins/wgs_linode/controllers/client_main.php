<?php
class ClientMain extends WgsLinodeController
{
    public function index() {
        // Set some variables to the view
        $this->set("var1", "value1");
 
        // Set variables all at once
        $var2 = "hello";
        $var3 = "world";
        $this->set(compact("var2", "var3"));
 
        // Automatically renders the view in /plugins/my_plugin/views/default/client_main.pdt
    }
}
?>