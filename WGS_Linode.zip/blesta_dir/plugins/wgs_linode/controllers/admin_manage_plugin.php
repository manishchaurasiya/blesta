<?php

class AdminManagePlugin extends AppController
{
    /**
     * Performs necessary initialization
     */
    private function init()
    {
        $this->parent->requireLogin();
        $this->uses(['WgsLinode.WgsLinodeConfig', "WgsLinode.WgsLinodeLicense", 'Companies']);
        Language::loadLang('wgs_linode_plugin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        $this->plugin_id = isset($this->get[0]) ? $this->get[0] : null;
        // Set the view to render for all actions under this controller
        // $this->view->setView(null, 'WgsLinode.default');
        // Set the page title
        $this->parent->structure->set(
            'page_title',
            Language::_(
                'WgsLinodeManage.title',
                true
            )
        );
    }
    public function index()
    {
        $this->init();
        $vars = [
            'plugin_id' => $this->plugin_id,
            'company_id' => Configure::get('Blesta.company_id')
        ];
        if (!isset($this->WgsLinodeConfig->settings) || empty($this->WgsLinodeConfig->settings) || count($this->WgsLinodeConfig->settings) == 0) {
            $this->parent->setMessage('error', ['error' => ['error' => Language::_('WgsGstTaxManage.!error.rules.settings.exist', true)]]);
        } else {
            foreach ($this->WgsLinodeConfig->settings as $settingName => $setting) {
                $vars[$setting] = (isset(($this->Companies->getSetting($vars["company_id"], $settingName))->value) ? ($this->Companies->getSetting($vars["company_id"], $settingName))->value : null);
            }
        }
        // // print_r($vars);die();
        // $this->view->setView('manage', 'wgs_linode.manage');
        if (isset($vars["license_key"]) && !empty($vars["license_key"])) {
            //    echo "frg";die();
            $licenseInfo = $this->WgsLinodeLicense->wgsLinodeValidateLicense($vars["license_key"], $vars["company_id"]);
            // Set errors, if any
            if (($errors = $this->WgsLinodeLicense->errors())) {
                $this->parent->setMessage('error', $errors);
            } else {
                // Handle License validation response
                if ($licenseInfo["status"] != "active") {
                    $this->parent->setMessage('error', ['error' => ['license' => Language::_('WgsLinodeManage.!error.license.valid', true)]]);
                }
            }
        }
        // echo "frgdfgtgz";die();
        if (!empty($this->post)) {
            // update the config options
            $this->post['company_id'] = Configure::get('Blesta.company_id');
            $this->WgsLinodeConfig->updateConfigOptions($this->post);
            // Set errors, if any
            if (($errors = $this->WgsLinodeConfig->errors())) {
                $this->parent->setMessage('error', $errors);
                $vars['vars'] = (object)$this->post;
            } else {
                // Handle successful add
                $this->parent->flashMessage('message', Language::_('WgsLinodeManage.!success.config_updated', true));
                $this->redirect($this->base_uri . 'settings/company/plugins/manage/' . $this->plugin_id);
            }
        }
        // Set the view to render
        $this->view->setView('manage', 'wgs_linode.manage');
        // Set variables all for the view at once
        $this->set(compact("vars"));
        // Return view to be displayed
        return $this->view->fetch();
    }

    /*  public function foo() {
        $this->init();
        return $this->partial("admin_manage_plugin_foo");
    }*/
}
