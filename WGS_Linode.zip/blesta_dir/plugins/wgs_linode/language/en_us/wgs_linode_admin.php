<?php

// Index

$lang['WgsLinodeAdmin.index.page_title'] = "WGS Linode > Dashboard";
$lang['WgsLinodeAdmin.index.section_title'] = "About";
$lang['WgsLinodeAdmin.product_settings.page_title'] = "WGS Linode > Product Settings";
$lang['WgsLinodeAdmin.product_features.page_title'] = "WGS Linode > Product Settings > Product Features";
$lang['WgsLinodeAdmin.assign_existing_server.page_title'] = "WGS Linode > Assign Existing Server";
$lang['WgsLinodeAdmin.stack_script.page_title'] = "WGS Linode > Stack Script";
$lang['WgsLinodeAdmin.nav.home.title'] = "Home";
$lang['WgsLinodeAdmin.nav.author.title'] = "WHMCS Global Services";
$lang['WgsLinodeAdmin.nav.product_settings.title'] = 'Product Settings';
$lang['WgsLinodeAdmin.nav.author.assign_existing_server'] = "Assign Existinbg Server";
$lang['WgsLinodeAdmin.nav.author.stack_script'] = "Stack Script";
$lang['WgsLinodeAdmin.nav.author.linode_documentation'] = "Linode Documentation";
$lang['WgsLinodeAdmin.footer.author.siteurl'] = "Site Url";
$lang['WgsLinodeAdmin.footer.author.supporturl'] = "Support Url";


// Upload Sign Page element titles

$lang['WgsLinodeAdmin.upload_sign.span.upload_file'] = "Upload File";
$lang['WgsLinodeAdmin.upload_sign.span.upload_file_note'] = "(Note: Only PNG file Allowed)";
$lang['WgsLinodeAdmin.upload_sign.span.upload_file_preview'] = "Preview";
$lang['WgsLinodeAdmin.upload_sign.span.drag_and_drop_note'] = "Choose an image file or drag it here.";



// fields

$lang['WgsLinodeAdmin.field_tax_type'] = "Tax Type";
$lang['WgsLinodeAdmin.field_invoice_type'] = "Invoice Type";
$lang['WgsLinodeAdmin.field_invoice_by'] = "Invoice By";
$lang['WgsLinodeAdmin.field_date_range_from'] = "Date Range From";
$lang['WgsLinodeAdmin.field_date_range_to'] = "Date Range To";
$lang['WgsLinodeAdmin.field_records_per_page'] = "Max Records Per Page";
$lang['WgsLinodeAdmin.field_submit'] = "Submit";
$lang['WgsLinodeAdmin.invoice.status.all'] = "All";
$lang['WgsLinodeAdmin.invoice.status.open'] = "Open";
$lang['WgsLinodeAdmin.invoice.status.closed'] = "Closed";
$lang['WgsLinodeAdmin.invoice.status.draft'] = "Draft";
$lang['WgsLinodeAdmin.invoice.status.void'] = "Void";
$lang['WgsLinodeAdmin.invoice.status.recurring'] = "Recurring";
$lang['WgsLinodeAdmin.invoice.status.pending'] = "Pending";
$lang['WgsLinodeAdmin.invoice.status.proforma'] = "Proforma";
$lang['WgsLinodeAdmin.invoice.status.total'] = "Total Records";
$lang['WgsLinodeAdmin.invoice.status.records_per_page'] = "Max Records Per Page";
$lang['WgsLinodeAdmin.invoice.filters.none'] = "None";
$lang['WgsLinodeAdmin.invoice.filters.date_billed'] = "Created Date";
$lang['WgsLinodeAdmin.invoice.filters.date_closed'] = "Paid Date";

// Features Name
$lang['WgsLinodeAdmin.feature.reset_root_password.name'] = "Reset Password";
$lang['WgsLinodeAdmin.feature.rebuild.name'] = "Rebuild";
$lang['WgsLinodeAdmin.feature.ip_list.name'] = "Ip List";
$lang['WgsLinodeAdmin.feature.add_private_ip.name'] = "Add Private IP";
$lang['WgsLinodeAdmin.feature.add_public_ip.name'] = "Add Public Ip";
$lang['WgsLinodeAdmin.feature.server_activity_log.name'] = "Server Activity Log";
$lang['WgsLinodeAdmin.feature.rescue.name'] = "Rescue";
$lang['WgsLinodeAdmin.feature.rdns.name'] = "Rdns";
$lang['WgsLinodeAdmin.feature.backup.name'] = "Backup";



// Field names

$lang['WgsLinodeAdmin.table.title.license'] = "License";
$lang['WgsLinodeAdmin.table.title.license.version'] = "Version";
$lang['WgsLinodeAdmin.table.title.license.status'] = "Status";
$lang['WgsLinodeAdmin.table.title.license.registeredto'] = "License Registered To";
$lang['WgsLinodeAdmin.table.title.license.registeredemail'] = "License Registered Email";
$lang['WgsLinodeAdmin.table.title.license.validdomains'] = "License Valid Domain";
$lang['WgsLinodeAdmin.table.title.license.author'] = "Author";
$lang['WgsLinodeAdmin.table.title.license.productname'] = "Product Name";
$lang['WgsLinodeAdmin.table.title.license.lastupdated'] = "Last Updated";
$lang['WgsLinodeAdmin.table.title.records.empty'] = "No Records Found.";


$lang['WgsLinodeAdmin.table.title.invoice.proforma.id'] = "#";
$lang['WgsLinodeAdmin.table.title.invoice.id'] = "#Invoice Id";
$lang['WgsLinodeAdmin.table.title.invoice.proforma'] = "#Proforma Invoice";
$lang['WgsLinodeAdmin.table.title.invoice.user'] = "User";
$lang['WgsLinodeAdmin.table.title.invoice.user.state'] = "State";
$lang['WgsLinodeAdmin.table.title.invoice.status'] = "Status";
$lang['WgsLinodeAdmin.table.title.invoice.payment_method'] = "Payment Method";
$lang['WgsLinodeAdmin.table.title.invoice.created_date'] = "Created Date";
$lang['WgsLinodeAdmin.table.title.invoice.paid_date'] = "Paid Date";


$lang['WgsLinodeAdmin.upload_sign.button.cancel'] = "Cancel";
$lang['WgsLinodeAdmin.upload_sign.button.upload'] = "Upload";

// Error messages

$lang['WgsLinodeAdmin.!error.license.valid'] = "The license key specified is invalid.";
$lang['WgsLinodeAdmin.!error.upload_field.valid'] = "The upload field key specified is invalid.";
$lang['WgsLinodeAdmin.!error.upload_dir.create'] = "Unable to create upload dir `plugins/wgs_linode/assets/upload`";
$lang['WgsLinodeAdmin.!error.image.upload'] = "Unknown error occured. Please try again.";
$lang['WgsLinodeAdmin.!error.upload_image.invalid'] = "Please choose a valid image. Only png images are allowed.";
$lang['WgsLinodeAdmin.!error.sync_api_data_with_database'] = "Stack scripts API is not working. Unable to sync scripts.";
$lang['WgsLinodeAdmin.!error.linode.server.api_token_not_working'] = "Linode server error! API token is not working.";


// Success messages
$lang['WgsLinodeAdmin.!success.features'] = "Product features updated successfully.";
$lang['WgsLinodeAdmin.!success.product.setting'] = "Product Setting updated successfully.";

$lang['WgsLinodeAdmin.!success.stack_script.is_public'] = "stackScript public status updated successfully.";
$lang['WgsLinodeAdmin.!success.stack_script.delete'] = "stackScript deleted successfully.";
$lang['WgsLinodeAdmin.!success.stack_script.create'] = "stackScript created successfully.";
$lang['WgsLinodeAdmin.!success.stack_script.update'] = "stackScript updated successfully.";

// Error messages
$lang['WgsLinodeAdmin.!error.features'] = "Unknown error occured.";
$lang['WgsLinodeAdmin.!error.product.setting'] = "Unknown error occured.";
$lang['WgsLinodeAdmin.!error.module'] = "WGS Linode module is not activated.";

// product settings page 

$lang['WgsLinodeAdmin.table.title.product_name'] = "Product name";
$lang['WgsLinodeAdmin.table.title.linode_plan'] = "Linode Plan";
$lang['WgsLinodeAdmin.table.title.kernal'] = "Kernal";
$lang['WgsLinodeAdmin.table.title.subscription_term'] = "Subscription Term";
$lang['WgsLinodeAdmin.table.title.swap_disk'] = "Swap Disk";
$lang['WgsLinodeAdmin.table.title.status'] = "Status";
$lang['WgsLinodeAdmin.table.title.stack_script'] = "Stack Script";
$lang['WgsLinodeAdmin.table.title.features'] = "Features";
$lang['WgsLinodeAdmin.table.title.action'] = "Action";
$lang['WgsLinodeAdmin.product_setting.breadcrumbs.title.dashboard'] = "Dashboard";
$lang['WgsLinodeAdmin.product_setting.breadcrumbs.title.product_setting'] = "Product Setting";
$lang['WgsLinodeAdmin.breadcrumbs.title.feature'] = "Feature Add";

$lang['WgsLinodeAdmin.table.data.field.name.company_id'] = "company_id";
$lang['WgsLinodeAdmin.table.data.field.name.product_id'] = "product_id";
$lang['WgsLinodeAdmin.table.data.field.name.linode_plan'] = "linode_plan";
$lang['WgsLinodeAdmin.table.data.field.name.kernel'] = "kernel";
$lang['WgsLinodeAdmin.table.data.field.name.subscription'] = "subscription";
$lang['WgsLinodeAdmin.table.data.field.name.swap'] = "swap";
$lang['WgsLinodeAdmin.table.data.field.name.status'] = "status";
$lang['WgsLinodeAdmin.table.data.field.name.stack_script'] = "stack_script";
$lang['WgsLinodeAdmin.table.data.field.name.status'] = "status";
$lang['WgsLinodeAdmin.table.button.data_tg_off'] = "OFF";
$lang['WgsLinodeAdmin.table.button.data_tg_on'] = "ON";
$lang['WgsLinodeAdmin.table.edit.button.title'] = "Edit";
$lang['WgsLinodeAdmin.table.save.button.name'] = "Product Setting Save";



//  edit product setting page

$lang['WgsLinodeAdmin.edit_product_setting.breadcrumbs.title.dashboard'] = "Dashboard";
$lang['WgsLinodeAdmin.edit_product_setting.breadcrumbs.title.product_setting'] = "Edit Product Setting";
$lang['WgsLinodeAdmin.edit_product_setting.breadcrumbs.title.feature'] = "Feature Add";
$lang['WgsLinodeAdmin.edit_product_setting.button.title.go_back'] = "Back";
$lang['WgsLinodeAdmin.edit_product_setting.button.title.save'] = "Save";


// assign existing server  

$lang['WgsLinodeAdmin.edit_product_setting.breadcrumbs.title.dashboard'] = "Dashboard";
$lang['WgsLinodeAdmin.edit_product_setting.breadcrumbs.title.assign_existing_server'] = "Assign Existing Server";
$lang['WgsLinodeAdmin.edit_product_setting.button.title.submit'] = "Submit";

$lang['WgsLinodeAdmin.edit_product_setting.service_type'] = "Service Type";
$lang['WgsLinodeAdmin.edit_product_setting.exist'] = "Existing";
$lang['WgsLinodeAdmin.edit_product_setting.new'] = "New";

$lang['WgsLinodeAdmin.edit_product_setting.label.clients'] = "Clients";
$lang['WgsLinodeAdmin.edit_product_setting.label.existing_service'] = "Existing Service";
$lang['WgsLinodeAdmin.edit_product_setting.label.linode_server'] = "Linode Server";
$lang['WgsLinodeAdmin.edit_product_setting.label.product'] = "Products";
$lang['WgsLinodeAdmin.edit_product_setting.label.payment_method'] = "Payment Method";
$lang['WgsLinodeAdmin.edit_product_setting.label.create_invoice'] = "Create Invoice";
$lang['WgsLinodeAdmin.edit_product_setting.label.send_email'] = "Send Email";
$lang['WgsLinodeAdmin.edit_product_setting.label.billing_cycle'] = "Billing Cycle";
$lang['WgsLinodeAdmin.edit_product_setting.label.linode_server'] = "Linode Server";


// stack script page  

$lang['WgsLinodeAdmin.stack_script.breadcrumbs.title.dashboard'] = "Dashboard";
$lang['WgsLinodeAdmin.stack_script.breadcrumbs.title.stack_script'] = "Stack Script";

$lang['WgsLinodeAdmin.table.data.field.name.stackscript_label'] = "StackScripts Label";
$lang['WgsLinodeAdmin.table.data.field.name.active_deploy'] = "Active Deploys";
$lang['WgsLinodeAdmin.table.data.field.name.compatible_images'] = "Comptiable Images";
$lang['WgsLinodeAdmin.table.data.field.name.public'] = "Public";
$lang['WgsLinodeAdmin.table.data.field.name.action'] = "Action";



// create stack script page


$lang['WgsLinodeAdmin.create_stack_script.form.error.stack_script_label'] = "This field is required";
$lang['WgsLinodeAdmin.create_stack_script.form.error.target_images'] = "This field is required";
$lang['WgsLinodeAdmin.create_stack_script.form.error.description'] = "This field is required";
$lang['WgsLinodeAdmin.create_stack_script.form.error.script'] = "This field is required";

$lang['WgsLinodeAdmin.create_stack_script.card.heading'] = "Tips"; 
$lang['WgsLinodeAdmin.create_stack_script.card.paragraph'] = "There are four default environment variables provided to you:"; 
$lang['WgsLinodeAdmin.create_stack_script.card.li_1'] = "LINODE_ID"; 
$lang['WgsLinodeAdmin.create_stack_script.card.li_2'] = "LINODE_LISHUSERNAME"; 
$lang['WgsLinodeAdmin.create_stack_script.card.li_3'] = "LINODE_RAM"; 
$lang['WgsLinodeAdmin.create_stack_script.card.li_4'] = "LINODE_DATACENTERID"; 


// package config options
//private ip
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.label.private_ip'] = "Private IP"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.name.wgs_linode_private_ip'] = "wgs_linode_private_ip"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.type.checkbox'] = "checkbox"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.addable'] = "true"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.editable'] = 0; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.name'] = "Private IP"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.value'] = 1; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.default'] = 0; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.status'] = "active"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.term'] = 1; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.period'] = "month"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.price'] = 3; 

//backup
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.label.backup'] = "Backup"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.name.wgs_linode_backup'] = "wgs_linode_backup"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.type.checkbox'] = "checkbox"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.addable'] = "true"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.editable'] = 0; 

$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.name'] = "Backup"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.value'] = 1; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.default'] = 0; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.status'] = "active"; 

$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.term'] = 1; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.period'] = "month"; 
$lang['WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.price'] = 3; 
