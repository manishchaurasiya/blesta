<?php

$lang['WgsLinode.custome_fields.linode_id'] = 'Linode Id';
$lang['WgsLinode.custome_fields.datacenter'] = 'Region';
$lang['WgsLinode.custome_fields.password'] = 'Root Password';
$lang['WgsLinode.custome_fields.config_id'] = 'Config Id';
$lang['WgsLinode.custome_fields.swap_disk_id'] = 'Swap Disk Id';
$lang['WgsLinode.custome_fields.main_disk_id'] = 'Main Disk Id';
$lang['WgsLinode.custome_fields.reverse_dns'] = 'Reverse DNS';
$lang['WgsLinode.custome_fields.resoucres_id'] = 'Resources Id';
$lang['WgsLinode.custome_fields.stackscript'] = 'StackScript';
$lang['WgsLinode.custome_fields.distribution'] = 'Images';






?>
