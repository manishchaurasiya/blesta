<?php

$lang['WgsLinodePlugin.name'] = 'WGS Linode';
$lang['WgsLinodeManage.title'] = "WGS Linode";
$lang['WgsLinodePlugin.add.field_license'] = 'Linode License key';
$lang['WgsLinodePlugin.add.field_apiUrl'] = 'Linode API URL';
$lang['WgsLinodePlugin.add.field_apiKey'] = 'Linode API Key';
$lang['WgsLinodePlugin.add.field_username'] = 'Linode Username';
$lang['WgsLinodePlugin.add.field_prefix'] = 'Linode Server Name Prefix';
$lang['WgsLinodePlugin.update.submit_update_config_options'] = 'Update Configurable Options';
$lang['WgsLinodePlugin.index.heading_settings'] = 'Settings';
$lang['WgsLinodeManage.index.boxtitle'] = "WGS Linode";
$lang['WgsLinodeManage.!error.license_key.valid'] = "License key specified is invalid.";
$lang['WgsLinodeManage.!error.api_url.valid'] = "API URL specified is invalid.";
$lang['WgsLinodeManage.!error.api_key.valid'] = "API key specified is invalid.";
$lang['WgsLinodeManage.!error.username.valid'] = "Username specified is invalid.";
$lang['WgsLinodeManage.!error.prefix.valid'] = "Linode server name prefix specified is invalid.";
$lang['WgsLinodeManage.!success.config_updated'] = "Updated successfully.";


?>