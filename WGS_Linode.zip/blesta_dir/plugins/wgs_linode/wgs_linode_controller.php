<?php

class WgsLinodeController extends AppController {

    public function preAction() {
        // Set the view directory to the default core view directory so that AppController preAction code uses the appropriate
        // directory for the structure file
        $this->structure->setDefaultView(APPDIR);
        parent::preAction();
        // Override default view directory with that of the plugin
        $this->view->view = "default";
    }
}

?>