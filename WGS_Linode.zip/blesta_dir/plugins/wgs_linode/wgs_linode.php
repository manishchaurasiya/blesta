<?php

use Blesta\Core\Util\Validate\Server;

class wgsLinode extends Module
{
    public function __construct()
    {
        // Load components required by this module
        Loader::loadComponents($this, ['Input']);
        // Load the language required by this module
        Language::loadLang('wgs_linode', null, dirname(__FILE__) . DS . 'language' . DS);
        // Load module config
        $this->loadConfig(dirname(__FILE__) . DS . 'config.json');
    }

    public function getPackageFields($vars = null)
    {
        Loader::loadHelpers($this, ['Html']);
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeLicense', 'WgsLinode.WgsLinodeApi', 'Companies']);
        $companyId = Configure::get('Blesta.company_id');
        foreach ($this->WgsLinodeConfig->settings as $key => $value) {
            $settings[$key] =  $this->Companies->getSetting($companyId, $key);
        }
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        $fields = new ModuleFields();
        $my_label = $fields->label("Test Module Field Label", "my_field_id");
        $fields->setField($my_label);
        // Create the field
        $my_field = $fields->fieldText("test_field_name", "default value", array('id' => "my_field_id"));
        foreach ($this->WgsLinodeConfig->customFields as $key => $value) {
            $type = $fields->label(Language::_('WgsLinode.custome_fields.' . $value, true), $value);
            $type->attach(
                $fields->fieldText(
                    "meta[$value]",
                    (isset($vars->meta["$value"]) ? $vars->meta["$value"] : null),
                    ['id' => "$value"]
                )
            );
            $fields->setField($type);
        }

        // set  datacenter fields
        $datacenterRegions = $this->WgsLinodeApi->getRegions();

        $regionList = [];
        foreach ($datacenterRegions["result"]->data as $regions) {
            if (array_key_exists($regions->id, $this->WgsLinodeConfig->datacenter)) {
                $regionList[$regions->id] =  $this->WgsLinodeConfig->datacenter[$regions->id];
            }
        }
        $type = $fields->label(Language::_('WgsLinode.custome_fields.datacenter', true), 'datacenter');
        $type->attach(
            $fields->fieldSelect(
                'meta[datacenter]',
                $regionList,
                (isset($vars->meta['datacenter']) ? $vars->meta['datacenter'] : null),
                ['id' => 'datacenter']
            )
        );
        $fields->setField($type);

        // get distribution images 
        $distributionImages = [];
        $images = $this->WgsLinodeApi->getDistibutionImages();
        foreach ($images['result']->data as $key => $image) {
            $distributionImages[$key] = $image->label;
        }
        $type = $fields->label(Language::_('WgsLinode.custome_fields.distribution', true), 'distribution');
        $type->attach(
            $fields->fieldSelect(
                'meta[distribution]',
                $distributionImages,
                (isset($vars->meta['distribution']) ? $vars->meta['distribution'] : null),
                ['id' => 'distribution']
            )
        );
        $fields->setField($type);
        return $fields;
    }
}
