// make secure ajax calls
function secureCall(data = {}, action = window.location.href, method = "POST", dataType = 'json') {
    if (data._csrf_token === undefined && window._csrfToken !== undefined) {
        data._csrf_token = window._csrfToken
    }
    return new Promise((resolve, reject) => {
        $(this).blestaRequest(
            method, action, data, resolve, reject, dataType
        );
    })
}

$(document).ready(function () {
    //assign new server
    $("#assign_new").click(async function () {
        try {
            var formdata = $("#assign_server").serialize() + '&action=assign_new';
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait..');
            var response = await secureCall(formdata, window.location.href, "POST", "string");
            var responseData = JSON.parse(response);
            if (responseData.status == 'success') {
                Swal.fire(
                    'Pending!',
                    responseData.msg,
                    'info'
                )
            } else {
                Swal.fire(
                    '',
                    responseData.msg,
                    'error'
                )
            }
        } catch (error) {
            console.log(error)
        } finally {
            $(this).html('<button type="button" name="Submit" value="Submit" class="btn btn btn-info" id="assign_new">Submit</button>');
        }
    });


    // get services related to clients name
    $("#Clients").on("change", async function () {
        try {
            var clientId = $(this).val();
            var response = await secureCall({ action: "onClientChange", clientId: clientId })
            var responseData = JSON.parse(response);
            var html = "";
            if (responseData != "") {
                $("#existing_service").attr('disabled', false);
                $.each(responseData, function (key, value) {
                    html += `<option value="` + key + `">` + value + `</option>`;
                });

            } else {
                $("#existing_service").attr('disabled', false);
                html += "<option value=''> There is no active services for this client. </option>";
            }
            $("#existing_service").html(html);
        } catch (error) {
            console.log(error);
        }
    });

    //assign existing services
    $("#assign_existing").click(async function(){
        try {
            $(this).html('<i class="fas fa-spinner fa-pulse"></i> wait..');
            var formdata = $("#assign_server").serialize() + '&action=assign_existing';
            var response = await secureCall(formdata, window.location.href, "POST", "string");

            console.log(response);
            var responseData = JSON.parse(response);
            if (responseData.status == 'success') {
                Swal.fire(
                    '',
                    responseData.msg,
                    'success'
                )
            } else {
                Swal.fire(
                    '',
                    responseData.msg,
                    'error'
                )
            }
        } catch (error) {
            console.log(error);
        } finally {
            $(this).html('<button type="button" name="Submit" value="Submit" class="btn btn btn-info" id="assign_existing">Submit</button>');
        }
    });
});


