<?php
/**
 * 
 *
 * Manages Configuration options for WGS Linode
 *
 * @package WgsLinodeTaxC
 * @subpackage blesta.plugins.wgs_linode_plugin.models
 * @copyright Copyright (c) WHMC
 * @license https://whmcsglobalservices.com/license The Blesta License Agreement
 * @link https://whmcsglobalservices.com/ Whmcs Global Services
 */
class WgsLinodeConfig extends WgsLinodeModel
{

    public function __construct()
    {

        parent::__construct();
        Language::loadLang('wgs_linode_plugin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
    }

    /**
     * update Configuration options with the given details
     *
     * @param array $vars An array of feed information including:
     *  - license_key License key of the module
     *  - company_id The company ID to make this feed a default feed for (optional)
     */
    public function updateConfigOptions(array $vars)
    {
        try {
            $rules = [
                'wgs_linode_license_key'=>[
                    'valid'=>[
                        'rule'=>'isEmpty',
                        'negate'=>true,
                        'message'=>$this->_('WgsLinodeManage.!error.license_key.valid')
                    ]
                ], 
                'wgs_linode_api_url'=>[
                    'valid'=>[
                        'rule'=>'isEmpty',
                        'negate'=>true,
                        'message'=>$this->_('WgsLinodeManage.!error.api_url.valid')
                    ]
                ], 
                'wgs_linode_api_key'=>[
                    'valid'=>[
                        'rule'=>'isEmpty',
                        'negate'=>true,
                        'message'=>$this->_('WgsLinodeManage.!error.api_key.valid')
                    ]
                ], 
                'wgs_linode_username'=>[
                    'valid'=>[
                        'rule'=>'isEmpty',
                        'negate'=>true,
                        'message'=>$this->_('WgsLinodeManage.!error.username.valid')
                    ]
                ], 
                'wgs_linode_prefix'=>[
                    'valid'=>[
                        'rule'=>'isEmpty',
                        'negate'=>true,
                        'message'=>$this->_('WgsLinodeManage.!error.prefix.valid')
                    ]
                ],                

            ];

            $this->Input->setRules($rules);

            if ($this->Input->validates($vars)) {
                Loader::loadModels($this, ["Companies"]);
                foreach ($this->settings as $settingName => $setting) {
                    if (!$this->Companies->setSetting($vars["company_id"], $setting, $vars[$setting], false, false)) {
                        if (($errors = $this->Companies->errors())) {
                            $this->Input->setErrors($errors);
                            return;
                        }
                    }
                }

                return true;
            }
        } catch (Exception $e) {
            // Error adding... 
            $this->Input->setErrors(['update'=> ['update'=>"dgg".$e->getMessage()]]);
            return;
        }
    }

}
