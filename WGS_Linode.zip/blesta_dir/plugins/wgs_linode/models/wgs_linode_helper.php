<?php

use Blesta\Core\Util\Input\Fields\InputFields;

/**
 * 
 *
 * Manages License information for WGS Linode
 *
 * @package WgsLinodeC
 * @subpackage blesta.plugins.wgs_linode_plugin.models
 * @copyright Copyright (c) WHMC
 * @license https://whmcsglobalservices.com/license The Blesta License Agreement
 * @link https://whmcsglobalservices.com/ Whmcs Global Services
 */
class WgsLinodeHelper extends WgsLinodeModel
{
    public function __construct()
    {
        parent::__construct();
        Loader::loadComponents($this, ['Input', 'Record']);
        Language::loadLang('wgs_linode_plugin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        Language::loadLang('wgs_linode_admin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
    }
    /**
     * Fetches the given package
     *
     * @param int $package_id The package ID to fetch
     * @return mixed A stdClass object representing the package, false if no such package exists
     */
    public function getProductsByModule($module_id)
    {
        $result = $this->Record->select($this->getSelectFieldList())->from('packages')->on('package_names.lang', '=', Configure::get('Blesta.language'))->leftJoin('package_names', 'package_names.package_id', '=', 'packages.id', false)->leftJoin('linode_product_setting', 'linode_product_setting.product_id', '=', 'packages.id', false)->where('module_id', '=', $module_id)->fetchAll();

        foreach ($result as $key => $value) {
            $features = [];
            $activeFeatures = [];
            $data = $this->getData("linode_features", ["product_id" => $value->id, "company_id" => Configure::get('Blesta.company_id')]);
            if (isset($data->feature) && !empty($data->feature)) {
                $features = json_decode($data->feature, true);
                foreach ($features as $featurekey => $isEnabled) {
                    if ($isEnabled) {
                        $activeFeatures[$featurekey] = true;
                    }
                }
            }
            $result[$key]->activeFeatures = $activeFeatures;
            $result[$key]->features = $features;
        }
        return $result;
    }

    /**
     * Gets a list a fields to fetch for packages
     *
     * @return array A list a fields to fetch for packages
     */
    private function getSelectFieldList()
    {
        return [
            'packages.id',
            'packages.id_format',
            'packages.id_value',
            'packages.module_id',
            'package_names.name' => 'name',
            'packages.qty',
            'packages.client_qty',
            'packages.module_row',
            'packages.module_group',
            'packages.taxable',
            'packages.single_term',
            'packages.status',
            'packages.hidden',
            'packages.company_id',
            'packages.prorata_day',
            'packages.prorata_cutoff',
            'packages.upgrades_use_renewal',
            'linode_product_setting.company_id',
            'linode_product_setting.product_id',
            'linode_product_setting.linode_plan',
            'linode_product_setting.kernel',
            'linode_product_setting.subscription',
            'linode_product_setting.swap',
            'linode_product_setting.stack_script',
            'linode_product_setting.status'
        ];
    }

    // ------   save or update product setting -------------------

    public function updateProductSetting($data)
    {
        Loader::loadModels($this, ['Companies', 'PackageOptionGroups', 'PackageOptions', 'ModuleManager']);

        $result = false;
        $packageStatus = $this->Record->select(['status'])->from('packages')->where("id", "=", $data["product_id"])->fetch();
        $productData = $this->Record->select()->from('linode_product_setting')->where("product_id", "=", $data["product_id"])->fetch();
        if (empty($productData)) {
            $result = $this->Record->insert('linode_product_setting', $data);

            //update packages status
            $status = $data["status"] == 0 ? "inactive" : "active";
            $this->Record->where("id", "=", $data["product_id"])->update("packages", ["status" => $status]);
        } else {
            $result = $this->Record->where("product_id", "=", $data["product_id"])->update('linode_product_setting', $data);

            //update packages status
            $status = $data["status"] == 0 ? "inactive" : "active";
            $this->Record->where("id", "=", $data["product_id"])->update("packages", ["status" => $status]);
        }

        if (!$result) {
            $this->Input->setErrors('error', ['error' => ['license' => Language::_('WgsLinodeAdmin.!error.product.setting', true)]]);
            return;
        }

        // get product ids
        $option_group_id = $this->getCompanySettingValue("wgs_linode_package_option_group");
        $productIDs = $this->Record->select(["product_id"])->from('linode_product_setting')->fetchAll();
        $productID = [];
        foreach ($productIDs as $key => $value) {
            $productID[$value->product_id] = $value->product_id;
        }
        // edit product group 
        $this->PackageOptionGroups->edit($option_group_id, ["name" => 'WGS Linode', "description" => "WGS Linode product config option", "packages" => $productID]);

        return $result;
    }

    // ------   save or update product features -------------------

    public function updateFeatures($company_id, $product_id, $feature)
    {
        $result = false;
        $productData = $this->Record->select()->from('linode_features')->where("product_id", "=", $product_id)->fetch();
        if (empty($productData)) {
            $result = $this->Record->set("company_id", $company_id)->set("product_id", $product_id)->set("feature", $feature)->insert('linode_features');
        } else {
            $result = $this->Record->where("product_id", "=", $product_id)->update('linode_features', ["feature" => $feature]);
        }

        if (!$result) {
            $this->Input->setErrors('error', ['error' => ['license' => Language::_('WgsLinodeAdmin.!error.features', true)]]);
            return;
        }
        return $result;
    }

    // ------   get product features -------------------

    public function getFeatures($product_id = false)
    {
        return $this->Record->select()->from('linode_features')->where("product_id", "=", $product_id)->fetch();
    }

    public function getData($tableName, $conditions = [], $isAll = false)
    {
        $result = $this->Record->select()->from($tableName);
        foreach ($conditions as $key => $value) {
            $result->where($key, "=", $value);
        }

        if ($isAll) {
            $result = $result->fetchAll();
        } else {
            $result = $result->fetch();
        }
        return $result;
    }

    public function getModuleClassByPricingId($package_pricing_id)
    {
        return $this->Record->select(['modules.*', 'packages.id' => 'package_id'])->from('package_pricing')->innerJoin('packages', 'packages.id', '=', 'package_pricing.package_id', false)->innerJoin('modules', 'modules.id', '=', 'packages.module_id', false)->where('package_pricing.id', '=', $package_pricing_id)->fetch();
    }

    // check product enable or not
    public function isProductEnabled($package_id)
    {
        // getting "stack_script" to check stack_script status is enabled or not 
        $productInfo = $this->Record->select(['status', 'stack_script'])->from('linode_product_setting')->where("product_id", "=", $package_id)->fetch();
        return (isset($productInfo->status) ? $productInfo->status : false);
    }


    public function createConfigOptions()
    {
        try {
            Loader::loadModels($this, ['Companies', 'PackageOptionGroups', 'PackageOptions', 'ModuleManager']);
            // create  packageOPtionGroup
            $packageConfigOptionGroup = false;

            // Create Config Option group if does not exist
            if (empty($packageConfigOptionGroup = $this->getCompanySettingValue("wgs_linode_package_option_group"))) {
                $packageConfigOptionGroup = $this->PackageOptionGroups->add([
                    "company_id" => Configure::get('Blesta.company_id'),
                    "name" => 'WGS Linode',
                    "description" => "WGS Linode Configuration Options",
                ]);

                // Check if any error occured while creating package option group else save group id
                if (($errors = $this->PackageOptionGroups->errors())) {
                    $this->Input->setErrors($errors);
                    return;
                } else {
                    // if (array_key_exists($regions->id, $this->datacenter)) {

                    $this->Companies->setSetting(Configure::get('Blesta.company_id'), "wgs_linode_package_option_group", $packageConfigOptionGroup);
                    // set and return error if company setting does not save
                    if (($errors = $this->Companies->errors())) {
                        $this->Input->setErrors($errors);
                        return;
                    }
                }
            }

            foreach ($this->getPackageConfigOptions() as $key => $getPackageConfigOption) {
                $getPackageConfigOption["groups"]["option_group_id"] = $packageConfigOptionGroup;

                if (!$this->checkPackageOptionExist($getPackageConfigOption["name"])) {
                    $this->PackageOptions->add($getPackageConfigOption);
                    if (($errors = $this->PackageOptions->errors())) {
                        $this->Input->setErrors($errors);
                        return;
                    }
                }
            }
        } catch (\Exception $error) {
            $this->Input->setErrors('error', ['error' => ['error' => $error->getMessage()]]);
            return;
        }
    }

    public function getCompanySettingValue($option_key = false)
    {
        try {
            Loader::loadModels($this, ['Companies']);
            $result = $this->Companies->getSetting(Configure::get('Blesta.company_id'), $option_key);
            return (isset($result->value) ? $result->value : false);
        } catch (\Exception $error) {
            $this->Input->setErrors('error', ['error' => ['error' => $error->getMessage()]]);
            return;
        }
    }

    public function getPackageConfigOptions()
    {
        return $packageConfigOptions = [
            [
                "company_id" => Configure::get('Blesta.company_id'),
                "label" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.label.private_ip', true),
                "name" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.name.wgs_linode_private_ip', true),
                "type" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.type.checkbox', true),
                "addable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.addable', true),
                "editable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.editable', true),
                "values" => [
                    [
                        "name" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.name', true),
                        "value" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.value', true),
                        "default" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.default', true),
                        "status" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.status', true),
                        "pricing" => [
                            [
                                "term" => Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.term', true),
                                "period" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.period', true),
                                "price" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.private_ip.values.pricing.price', true),
                            ]
                        ]
                    ]
                ]
            ],
            [
                "company_id" => Configure::get('Blesta.company_id'),
                "label" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.label.backup', true),
                "name" =>   Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.name.wgs_linode_backup', true),
                "type" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.type.checkbox', true),
                "addable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.addable', true),
                "editable" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.editable', true),
                "values" => [
                    [
                        "name" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.name', true),
                        "value" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.value', true),
                        "default" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.default', true),
                        "status" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.status', true),
                        "pricing" => [
                            [
                                "term" => Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.term', true),
                                "period" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.period', true),
                                "price" =>  Language::_('WgsLinodeAdmin.create.packageConfigOptions.backup.values.pricing.price', true),
                            ]
                        ]
                    ]
                ]
            ]
        ];
    }


    public function checkPackageOptionGroupsExist($company_id, $name)
    {
        return $this->Record->select(["id"])->from('package_option_groups')->where("company_id", "=", $company_id)->where("name", "=", $name)->fetch();
    }

    public function checkPackageOptionExist($option_name)
    {
        return $this->Record->select()->from('package_options')->where("company_id", "=", Configure::get('Blesta.company_id'))->where("name", "=", $option_name)->fetch();
    }

    public function getConfigSetting()
    {
        $settings = [];
        foreach ($this->settings as $key => $value) {
            $settings[$key] =  $this->Companies->getSetting(Configure::get('Blesta.company_id'), $key);
        }
        return $settings;
    }

    private function configureApiParams()
    {
        if (!isset($this->WgsLinodeApi)) {
            Loader::loadModels($this, ['WgsLinode.WgsLinodeApi']);
        }

        $wgsLinodeConfigSetting = $this->getConfigSetting();
        $this->WgsLinodeApi->setParams($wgsLinodeConfigSetting['wgs_linode_api_url']->value, $wgsLinodeConfigSetting['wgs_linode_api_key']->value);
    }

    public function getApiCustomFields()
    {
        $this->configureApiParams();

        $result = [
            "server_image" => [],
            "datacenter" => [],
            "stackscript" => [],
        ];

        $datacenterRegions = $this->WgsLinodeApi->getRegions();
        if ($datacenterRegions["httpcode"] == 200) {
            foreach ($datacenterRegions["result"]->data as $regions) {
                if (array_key_exists($regions->id, $this->datacenter)) {
                    $result["datacenter"][$regions->id] =  $this->datacenter[$regions->id];
                }
            }
        }

        // get distribution images 
        $serverImage = $this->WgsLinodeApi->getDistibutionImages();
        if ($serverImage["httpcode"] == 200) {
            foreach ($serverImage['result']->data as $key => $serverImage) {
                $result["server_image"][$serverImage->id] = $serverImage->label;
            }
        }

        // stackScript 
        $stackScript = $this->WgsLinodeApi->getScript();
        if ($stackScript["httpcode"] == 200) {
            foreach ($stackScript['result']->data as $key => $stackScripts) {
                $result["stackscript"][$stackScripts->id] = $stackScripts->label;
            }
        }
        foreach ($result as $key => $value) {
            if (!isset($this->customFields[$key])) {
                unset($result[$key]);
            }
        }
        return $result;
    }

    public function generateModuleFields($params, array $vars, $moduleFieldType = 'meta')
    {
        Loader::loadHelpers($this, ['Html']);
        if (!empty($vars)) {
            // get meta data fom local table 
            $images = $this->Record->select(["images"])->from("linode_stackscripts")->where("scriptid", "=", $vars["stackscript"])->fetch();
            $image = explode(",", $images->images);
            $output = [];
            if (isset($params["server_image"]) && !empty($params["server_image"])) {
                foreach ($params["server_image"]["value"] as $key => $value) {
                    if (in_array($key, $image)) {
                        $output[$key] = $value;
                    }
                }
            }
        }
        $filters = new InputFields();
        foreach ($params as $key => $param) {
            if ($param["type"] == "text") {
                // Create text label
                $field = $filters->label($param["label"], $key);
                // Create "filters[field]" input field
                $field->attach(
                    $filters->fieldText(
                        $moduleFieldType . '[' . $key . ']',
                        isset($vars[$key]) ? $vars[$key] :  $this->Html->ifSet($param["value"]), // Pre-populate the field if it is defined in $vars
                        [
                            'id' => $key,
                            'class' => 'form-control',
                            'placeholder' => $param["label"]
                        ]
                    )
                );
                $filters->setField($field);
            } elseif ($param["type"] == "select") {
                // Create label
                $field = $filters->label($param["label"], $key);
                // Create "filters[]" select field
                //check script images assign or not
                if (isset($vars["stackscript"]) && !empty($vars["stackscript"] && $key == "server_image")) {
                    $field->attach(
                        $filters->fieldSelect(
                            $moduleFieldType . '[' . $key . ']',
                            isset($output) ? $output : $param,
                            isset($vars[$key]) ? $vars[$key] : null,
                            ['id' => $key, 'class' => 'form-control']
                        )
                    );
                    $filters->setField($field);
                } else {
                    $field->attach(
                        $filters->fieldSelect(
                            $moduleFieldType . '[' . $key . ']',
                            (isset($param["value"]) ? $param["value"] : []),
                            isset($vars[$key]) ? $vars[$key] : null,
                            ['id' => $key, 'class' => 'form-control']
                        )
                    );
                    $filters->setField($field);
                }
            }
        }

        // You can set HTML code as well!
        // $filters->setHtml('
        //     <script type="text/javascript">alert("It Works!");</script>
        // ');

        return $filters;
    }

    // update api data in database table linode_stackscripts
    public function updateApiData()
    {
        $this->configureApiParams();

        // Get local stack scripts from database
        $getLocalStackScripts = $this->Record->select()->from("linode_stackscripts")->fetchAll();
        $localStackScripts = [];
        foreach ($getLocalStackScripts as $key => $value) {
            $localStackScripts[$value->scriptid] = (array)$value;
        }
        $syncedStackScripts = $localStackScripts;
        $getApiStackScripts = $this->WgsLinodeApi->getScript();
        if (isset($getApiStackScripts["httpcode"]) && $getApiStackScripts["httpcode"] == 200 && isset($getApiStackScripts["result"]->data)) {
            // get script data
            $apiScriptData = [];
            $apiScriptDataIds = [];
            foreach ($getApiStackScripts["result"]->data as $key => $value) {
                $apiScriptData[$value->id] = $value;
                $apiScriptDataIds[$value->id] = $value->id;
                $syncedStackScripts[$value->id] = [
                    'id' => false,
                    'company_id' => Configure::get('Blesta.company_id'),
                    'scriptid' => $value->id,
                    'label' => $value->label,
                    'description' => $value->description,
                    'script' => $value->script,
                    'revision' => $value->rev_note,
                    'images' => implode(',', $value->images),
                    'deployments_active' => $value->deployments_active,
                    'is_public' => (isset($value->is_public) ? (int)$value->is_public : 0),
                    'is_found' => true
                ];

                if (isset($localStackScripts[$value->id])) {
                    $syncedStackScripts[$value->id]["id"] = $localStackScripts[$value->id]["id"];
                    unset($localStackScripts[$value->id]);
                }
            }

            foreach ($syncedStackScripts as $key => $script) {
                if (isset($script["is_found"])) {
                    unset($script["is_found"]);
                    if ($script["id"]) {
                        // update here
                        $this->Record->where("scriptid", "=", $script["scriptid"])->update("linode_stackscripts", $script);
                    } else {
                        // insert here
                        unset($script["id"]);
                        $this->Record->insert("linode_stackscripts", $script);
                    }
                } else {
                    // remove this script
                    $this->Record->from("linode_stackscripts")->where("scriptid", "=", $script["scriptid"])->delete();
                }
            }


            return true;
        }
        $this->Input->setErrors('error', ['error' => ['error' => Language::_('WgsLinodeAdmin.!error.sync_api_data_with_database', true)]]);
        return false;
    }

    // get datacenter region
    public function getDataCenterRegion($regionId)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig']);
        if (array_key_exists($regionId, $this->WgsLinodeConfig->datacenter)) {
            return $this->WgsLinodeConfig->datacenter[$regionId];
        }
    }

    // reset root password 
    public function resetRootPassword($newPassword, $linodeId, $status, $package_id)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeApi']);
        $settings = $this->getConfigSetting();
        $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
        if ($status != "offline") {
            $resposnce = $this->WgsLinodeApi->serverShutDown($linodeId);

            // PRINT_R($this->WgsLinodeApi->getseverdetails($linodeId));
            while ($this->WgsLinodeApi->getseverdetails($linodeId)["result"]->status == 'shutting_down') {
                sleep(3);
            }
            if ($resposnce["httpcode"] == 200) {
                $resp = $this->WgsLinodeApi->resetRootPassword($linodeId);
                echo "<pre>";
                print_r($resp);

                // update password in package_meta table
                $this->Record->where("package_id", "=", $package_id)->where("key", "=", "password")->update("package_meta", ["value" => $newPassword]);
            } else {
                // set error here
            }
        }
        //rebooting server
        $this->WgsLinodeApi->serverReeBoot($linodeId);
    }

    //get server logs 
    public function getServerLogs($serverLogsData, $serverId)
    {
        $logs = [];
        $count = 1;
        foreach ($serverLogsData as $key => $value) {
            if (isset($value->entity->id) && !empty($value->entity->id) && $serverId == $value->entity->id) {
                $logs[$value->id] =  [
                    "created" => $value->created,
                    "duration" => $value->duration,
                    "status" => $value->status,
                    "action" => $value->action,
                ];
                if ($count >= 15) {
                    break;
                }
                $count++;
            }
        }
        return $logs;
    }

    // get ips
    public function ipsLists($linode_id, $ipAddress = null)
    {
        try {
            $output = [];
            Loader::loadModels($this, ['WgsLinode.WgsLinodeApi']);
            $settings = $this->getConfigSetting();
            $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
            $allips = $this->WgsLinodeApi->getIPs($linode_id, $ipAddress);

            if ($allips['httpcode'] == 200) {
                foreach ($allips['result'] as $ipType => $value) {
                    if ($ipType == 'ipv4') {
                        foreach ($value as $key => $ipvalues) {
                            if (is_array($ipvalues) && !empty($ipvalues)) {
                                foreach ($ipvalues as $ip) {
                                    array_push($output, $ip);
                                }
                            }
                        }
                    } else {
                        array_push($output, $value->slaac);
                    }
                }
            }
            return $output;
        } catch (\Exception $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }

    // generate graph data of IPv4 and IPv6
    public function graphDataIPv4Ip6($getgraphdetail, $action)
    {
        try {
            if (isset($getgraphdetail['errors'])) {
                $script =  "<span style='font-weight: 700;'>" . $getgraphdetail['errors'][0]['reason'] . "</span>";
            } else {
                $datapoints_out = '';
                foreach ($getgraphdetail['result']->data->$action->out as $netv4_out) {
                    $timestampSeconds = $netv4_out[0] / 1000;
                    $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                    $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                    $memory_datavalue = $netv4_out[1];
                    $datapoints_out .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                }
                $datapoints_out = rtrim($datapoints_out, ',');
                $datapoints_in = '';
                foreach ($getgraphdetail['result']->data->$action->in as $netv4_in) {
                    $timestampSeconds = $netv4_in[0] / 1000;
                    $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                    $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                    $memory_datavalue = $netv4_in[1];
                    $datapoints_in .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                }
                $datapoints_in = rtrim($datapoints_in, ',');
                $datapoints_private_in = '';
                foreach ($getgraphdetail['result']->data->$action->private_in as $netv4_private_in) {
                    $timestampSeconds = $netv4_private_in[0] / 1000;
                    $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                    $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                    $memory_datavalue = $netv4_private_in[1];
                    $datapoints_private_in .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                }
                $datapoints_private_in = rtrim($datapoints_private_in, ',');
                $datapoints_private_out = '';
                foreach ($getgraphdetail['result']->data->$action->private_out as $netv4_private_out) {
                    $timestampSeconds = $netv4_private_out[0] / 1000;
                    $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                    $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                    $memory_datavalue = $netv4_private_out[1];
                    $datapoints_private_out .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                }

                $title = (($action == "netv6") ? "IPv6" : "IPv4");
                $datapoints_private_out = rtrim($datapoints_private_out, ',');
                $script = "<div id='container' style='min-width: 310px; height: 400px; margin: 0 auto;text-align:center;'></div>
                <script>
                    jQuery(function () {
                        Highcharts.chart('container',{
                            chart: {zoomType: 'x'}, title: {text: '$title Traffic'},
                            xAxis: {type: 'datetime', tickPixelInterval: 250,},
                            yAxis: {title: {text: 'Percent'}},min:0,
                            tooltip: {
                                crosshairs: [true, true],
                                headerFormat: '{point.x:%A, %b %e, %Y, %l:%P}<br/>',
                                pointFormat: '<span style=\"color:{point.color}\">\u25CF</span> {series.name}: <b>{point.y}</b><br/>'
                            },
                            plotOptions: {
                                area: {
                                    fillColor: {
                                        linearGradient: {x1: 0, y1: 0, x2: 0, y2: 1},
                                        stops: [
                                            [0, Highcharts.getOptions().colors[0]],
                                            [1, Highcharts.getOptions().colors[0]]
                                        ]
                                    },
                                    marker: {
                                        radius: 2
                                    },
                                    lineWidth: 1,
                                    states: {
                                        hover: {
                                            lineWidth: 1
                                        }
                                    },
                                    threshold: null
                                },
                                spline: {
                                    marker: {
                                        enabled: false
                                    }
                                }
                            },
                            color:['#FDE67D','#E37ECA','#7ED6AA','#98BFEB'],
                            series: [{
                                    type: 'area',
                                    name: 'Private Outbound',
                                    data: [" . $datapoints_private_out . "],
                                        color:'rgb(253, 230, 125)'
                                },{
                                    type: 'areaspline',
                                    name: 'Private Inbound',
                                    data: [" . $datapoints_private_in . "],
                                        color:'rgb(227, 125, 202)'
                                },{
                                    type: 'areaspline',
                                    name: 'Public Outbound',
                                    data: [" . $datapoints_out . "], 
                                    color:'rgb(125, 214, 169)'
                                },{
                                    type: 'areaspline',
                                    name: 'Public Inbound',
                                    data: [" . $datapoints_in . "],
                                        color:'rgb(152, 191, 235)'
                                }
                                ]
                        });

                    });
                </script>";
            }
            echo $script;
            exit();
        } catch (\Exception $error) {
            //throw $th;
        }
    }

    // generete graph data of cpu usage
    public function graphDataCpu($getgraphdetail, $action)
    {
        if (isset($getgraphdetail['errors'])) {
            $script =  "<span style='font-weight: 700;'>" . $getgraphdetail['errors'][0]['reason'] . "</span>";
        } else {
            $datapoints = '';
            foreach ($getgraphdetail['result']->data->$action as $cpu) {
                $timestampSeconds = $cpu[0] / 1000;
                $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds)); //date('Y,m,d,H,i,s', $timestampSeconds);
                $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                $memory_datavalue = $cpu[1];
                //if($memory_datavalue > 0){
                $datapoints .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                //}
            }
            $datapoints = rtrim($datapoints, ',');
            //print_r($datapoints);
            $script = "<div id='container' style='min-width: 310px; height: 400px; margin: 0 auto;text-align:center;'></div>
            <script>
                jQuery(function () {
                    Highcharts.chart('container',{
                        chart: {zoomType: 'x'}, title: {text: 'CPU Usage'},
                        xAxis: {type: 'datetime', tickPixelInterval: 250,},
                        yAxis: {title: {text: 'Percent'}},min:0, legend: {enabled: false},
                            tooltip: {
                            crosshairs: [true, true],
                            headerFormat: '{point.x:%A, %b %e, %Y, %l:%P}<br/>',
                            pointFormat: '<span style=\"color:{point.color}\">\u25CF</span> {series.name}: <b>{point.y}</b><br/>'
                        },
                        plotOptions: {
                            area: {
                                fillColor: {
                                    linearGradient: {x1: 0, y1: 0, x2: 0, y2: 1},
                                    stops: [
                                        [0, Highcharts.getOptions().colors[0]],
                                        [1, Highcharts.getOptions().colors[0]]
                                    ]
                                },
                                marker: {
                                    radius: 2
                                },
                                lineWidth: 1,
                                states: {
                                    hover: {
                                        lineWidth: 1
                                    }
                                },
                                threshold: null
                            },
                            spline: {
                                marker: {
                                    enabled: false
                                }
                            }
                        },
                        series: [{
                                type: 'area',
                                name: 'CPU %',
                                data: [" . $datapoints . "],
                                color:'rgb(152, 191, 235)'
                            }],
                                exporting: {
                        chartOptions: {
                            plotOptions: {
                                series: {
                                    dataLabels: {
                                        enabled: true
                                    }
                                }
                            }
                        }
                    }
                });
                });
            </script>";
        }
        echo $script;
        exit();
    }

    // generete graph data of diskio_graph usage
    public function graphDataIo($getgraphdetail)
    {
        if (isset($getgraphdetail['errors'])) {
            $script =  "<span style='font-weight: 700;'>" . $getgraphdetail['errors'][0]['reason'] . "</span>";
        } else {
            $datapoints_io = '';
            foreach ($getgraphdetail["result"]->data->io->io as $io) {
                $timestampSeconds = $io[0] / 1000;
                $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                $memory_datavalue = $io[1];
                if ($memory_datavalue > 0) {
                    $datapoints_io .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                }
            }
            $datapoints_io = rtrim($datapoints_io, ',');
            $datapoints_swap = '';
            foreach ($getgraphdetail["result"]->data->netv6->in as $swap) {
                $timestampSeconds = $swap[0] / 1000;
                $memory_newtime = date('Y,m,d,H,i,s', strtotime("-1 months", $timestampSeconds));
                $memory_datevalue2 = 'Date.UTC(' . $memory_newtime . ')';
                $memory_datavalue = $swap[1];
                //if($memory_datavalue > 0){
                $datapoints_swap .= "[" . $memory_datevalue2 . ", " . $memory_datavalue . "],";
                //}
            }
            $datapoints_swap = rtrim($datapoints_swap, ',');
            $script = "<div id='container' style='min-width: 310px; height: 400px; margin: 0 auto;text-align:center;'></div>
            <script>
            jQuery(function () {
                Highcharts.chart('container',{
                    // chart: {zoomType: 'x'}, title: {text: 'I/O Traffic'},
                    xAxis: {type: 'datetime', tickPixelInterval: 250,},
                    yAxis: {title: {text: 'Percent'}},min:0,
                    tooltip: {
                        crosshairs: [true, true],
                        headerFormat: '{point.x:%A, %b %e, %Y, %l:%P}<br/>',
                        pointFormat: '<span style=\"color:{point.color}\">\u25CF</span> {series.name}: <b>{point.y}</b><br/>'
                    },
                    plotOptions: {
                        area: {
                            fillColor: {
                                linearGradient: {x1: 0, y1: 0, x2: 0, y2: 1},
                                stops: [
                                    [0, Highcharts.getOptions().colors[0]],
                                    [1, Highcharts.getOptions().colors[0]]
                                ]
                            },
                            marker: {
                                radius: 2
                            },
                            lineWidth: 1,
                            states: {
                                hover: {
                                    lineWidth: 1
                                }
                            },
                            threshold: null
                        },
                        spline: {
                            marker: {
                                enabled: false
                            }
                        }
                    },
                    color:['#FDE67D','#E37ECA','#7ED6AA','#98BFEB'],
                    series: [{
                            type: 'area',
                            name: 'I/O Rate',
                            data: [" . $datapoints_io . "],
                                color:'rgb(253, 230, 125)'
                        },{
                            type: 'areaspline',
                            name: 'Swap Rate',
                            data: [" . $datapoints_swap . "],
                                color:'rgb(227, 125, 202)'
                        }
                        ]
                });

            });
        </script>";
        }
        echo $script;
        exit();
    }

    // create array for invoice when user add extra feature from cliend tab(my services)
    public function createArrayForInvoice($service)
    {
        $date = date('d-m-Y H:i:s');
        $cliend_id = $service->client_id;
        $service_id = $service->id;
        return  [
            "client_id" => $cliend_id,
            "date_billed" => $date,
            "date_due" => $date,
            "date_closed" => null,
            "date_autodabited" => null,
            "status" => "active",
            "currency" => "USD",
            "note_public" => null,
            "note_private" => null,
            "lines" => [
                [
                    "service_id" =>  $service_id,
                    "description" => "requested for backup enable",
                    "qty" => 1,
                    "amount" => 3.00,
                    "tax" => "",
                ]
            ],
            "term" => "",
            "period" => "",
            "duration_time" => "",
            "recur_date_billed" => "",
            "delivery" => ["email"],
        ];
    }

    /*generate Strong Password */
    public function generateStrongPassword($length = 9, $add_dashes = false, $available_sets = 'luds')
    {
        try {
            $sets = array();
            if (strpos($available_sets, 'l') !== false)
                $sets[] = 'abcdefghjkmnpqrstuvwxyz';
            if (strpos($available_sets, 'u') !== false)
                $sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
            if (strpos($available_sets, 'd') !== false)
                $sets[] = '23456789';
            if (strpos($available_sets, 's') !== false)
                $sets[] = '!@#$%&*?';
            $all = '';
            $password = '';
            foreach ($sets as $set) {
                $password .= $set[array_rand(str_split($set))];
                $all .= $set;
            }
            $all = str_split($all);
            for ($i = 0; $i < $length - count($sets); $i++)
                $password .= $all[array_rand($all)];
            $password = str_shuffle($password);
            if (!$add_dashes)
                return $password;
            $dash_len = floor(sqrt($length));
            $dash_str = '';
            while (strlen($password) > $dash_len) {
                $dash_str .= substr($password, 0, $dash_len) . '-';
                $password = substr($password, $dash_len);
            }
            $dash_str .= $password;
            return $dash_str;
        } catch (\Exception $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }

    public function getLinodeId($service)
    {
        try {
            $serverMeta = [];
            foreach ($service->fields as $key => $value) {
                $serverMeta[$value->key] = $value->value;
            }
            return $serverMeta;
        } catch (\Exception $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }
    public function getActiveServerName($activeServer)
    {

        try {
            $server = [];
            foreach ($activeServer["result"]->data as $key => $value) {
                $server[$value->id] = $value->label;
            }
            return $server;
        } catch (\Throwable $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }

    public function serviceInvoice($clientId, $serviceId, $price, $billing_cycle)
    {
        $date = date('y-m-d H:i:s');
        $dateRenews = new DateTime("+1 $billing_cycle");
        $recur_date_billed = $dateRenews->format("y-m-d H:i:s");

        return  [
            "client_id" => $clientId,
            "date_billed" => $date,
            "date_due" => $recur_date_billed,
            "date_closed" => null,
            "date_autodabited" => null,
            "status" => "active",
            "currency" => "USD",
            "note_public" => null,
            "note_private" => null,
            "lines" => [
                [
                    "service_id" =>  $serviceId,
                    "description" => "services added by the admin!",
                    "qty" => 1,
                    "amount" => $price,
                    "tax" => "",
                ]
            ],
            "term" => 1,
            "period" => $billing_cycle,
            "duration" => null,
            "duration_time" => null,
            "recur_date_billed" => $recur_date_billed,
            "delivery" => ["email"],
        ];
    }
}
