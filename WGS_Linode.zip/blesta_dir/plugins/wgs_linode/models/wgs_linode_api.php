<?php

/**
 * 
 *
 * Manages API calls for WGS Linode
 *
 * @package WgsLinodeC
 * @subpackage blesta.plugins.wgs_linode_plugin.models
 * @copyright Copyright (c) WHMC
 * @license https://whmcsglobalservices.com/license The Blesta License Agreement
 * @link https://whmcsglobalservices.com/ Whmcs Global Services
 */
class WgsLinodeAPI extends WgsLinodeModel
{
    public $baseUrl, $apiKey, $endPoint, $action;

    public $method = "GET";
    public $data = [];
    public $header = [];
    public $last_request = [];

    public function __construct()
    {
        parent::__construct();
        Loader::loadComponents($this, ['Input', 'Record']);
        Language::loadLang('wgs_linode_plugin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
        Language::loadLang('wgs_linode_admin', null, PLUGINDIR . 'wgs_linode' . DS . 'language' . DS);
    }

    private function __curlCall()
    {
        $this->curl = curl_init();

        switch ($this->method) {
            case 'POST':
                curl_setopt($this->curl, CURLOPT_POST, 1);
                curl_setopt($this->curl, CURLOPT_POSTFIELDS, (count($this->data) > 0 ? json_encode($this->data) : ""));
                break;

            case 'PUT':
                curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($this->curl, CURLOPT_POSTFIELDS, (count($this->data) > 0 ? json_encode($this->data) : ""));
                break;

            case 'DELETE':
                curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                curl_setopt($this->curl, CURLOPT_POSTFIELDS, (count($this->data) > 0 ? json_encode($this->data) : ""));
                break;

            default:
                curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, 'GET');
        }

        curl_setopt($this->curl, CURLOPT_URL, $this->baseUrl . $this->endPoint);

        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 0);

        curl_setopt($this->curl, CURLOPT_MAXREDIRS, 10);

        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 0);

        curl_setopt($this->curl, CURLOPT_TIMEOUT, 10); //timeout in seconds

        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, 1);

        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $this->header);

        $response = curl_exec($this->curl);

        $httpCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);

        $this->last_request = [
            "url" => $this->baseUrl . $this->endPoint,
            "params" => $this->data,
            "response" => [
                "httpCode" => $httpCode,
                "result" => $response
            ]
        ];

        if (curl_errno($this->curl)) {
            throw new \Exception(curl_error($this->curl));
        }
        // \Modules::save_log("Addons", "WGSLinodeManager", $this->action, ["url" => $this->baseUrl . $this->endPoint], $response);
        return ['httpcode' => $httpCode, 'result' => json_decode($response)];
    }

    /* Check api connection*/
    public function checkConnect()
    {
        $this->endPoint = "images/";
        $this->action = "Test Connection";

        $response =  $this->__curlCall();
        return $response;
    }

    /*To get types */
    public function getTypes()
    {
        $this->endPoint = "linode/types/";
        $this->action = "Getting linode types";
        $response =  $this->__curlCall();
        return $response;
    }

    /*To get kernels  */
    public function getKernels()
    {
        $this->endPoint = "linode/kernels?page_size=399";
        //$this->endPoint = "linode/kernels";
        $this->action = "Getting linode kernels";

        $response =  $this->__curlCall();
        return $response;
    }

    /*Images List */
    public function getImages()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeHelper']);
        //setting header null to get only public images
        $this->header = [];
        $this->endPoint = "images";
        $this->action = "Getting Images List";
        //setting header 
        $settings = $this->WgsLinodeHelper->getConfigSetting();
        $this->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);

        $response =  $this->__curlCall();
        return $response;
    }

    /*get regions */
    public function getRegions()
    {
        $this->endPoint = "regions";
        $this->action = "Getting region list";
        $response =  $this->__curlCall();
        return $response;
    }

    /*get distribution images */
    public function getDistibutionImages()
    {
        $this->endPoint = "images";
        $this->action = "Getting Images List";
        $response =  $this->__curlCall();
        return $response;
    }

    // create stackscript  
    public function createScript($params)
    {
        $this->endPoint = "linode/stackscripts";
        $this->data = $params;
        $this->method = "POST";
        $this->action = "Creating stackScript";
        $response =  $this->__curlCall();
        return $response;
    }

    // update stackScript
    public function updateScript($scriptId, $params)
    {
        $this->endPoint = "linode/stackscripts/{$scriptId}";
        $this->data = $params;
        $this->method = "PUT";
        $this->action = "Update stackScript";
        $response =  $this->__curlCall();
        return $response;
    }

    // update stackScript
    public function deleteScript($scriptId)
    {
        $this->endPoint = "linode/stackscripts/{$scriptId}";
        $this->method = "DELETE";
        $this->action = "Delete stackScript";
        $response =  $this->__curlCall();
        return $response;
    }

    // update stackScript
    public function getScript()
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeHelper']);
        $userName = $this->WgsLinodeHelper->getCompanySettingValue("wgs_linode_username");
        $this->endPoint = "linode/stackscripts";
        $this->action = "get all stackScript";
        $this->header[2] = 'X-Filter: {"username":"' . $userName . '"}';
        $response =  $this->__curlCall();
        return $response;
    }

    // linode server detail view  by id
    public function getseverdetails($linodeId)
    {
        $this->endPoint = "linode/instances/{$linodeId}";
        $this->action = "get server details";
        $response =  $this->__curlCall();
        return $response;
    }
    // get active server 
    public function getActiveServer()
    {
        $this->endPoint = "linode/instances";
        $this->action = "get active server";
        $response =  $this->__curlCall();
        return $response;
    }

    // linode server shut down
    public function serverShutDown($linodeId)
    {
        $this->method = "POST";
        $this->endPoint = "linode/instances/{$linodeId}/shutdown";
        $this->action = "server shut down";
        $response =  $this->__curlCall();
        return $response;
    }

    //reboot linode server
    public function serverReBoot($linodeId)
    {
        $this->method = "POST";
        $this->endPoint = "linode/instances/{$linodeId}/reboot";
        $this->action = "server Reeboot";
        $response =  $this->__curlCall();
        return $response;
    }

    //reset root password
    public function resetRootPassword($linodeId, $password)
    {
        $this->method = "POST";
        $this->data = [
            "root_pass" => $password,
        ];
        $this->endPoint = "linode/instances/{$linodeId}/password";
        $this->action = "reset root password";
        $response =  $this->__curlCall();
        return $response;
    }

    //server active log
    public function serverLogs()
    {
        $this->endPoint = "account/events";
        $this->action = "get server logs";
        $response =  $this->__curlCall();
        return $response;
    }

    //server active log
    public function getDisks($linodeId)
    {
        $this->endPoint = "linode/instances/{$linodeId}/disks";
        $this->action = "get disk name";
        $response =  $this->__curlCall();
        return $response;
    }
    //boot linode server
    public function serverBoot($linodeId)
    {
        $this->method = "POST";
        $this->endPoint = "linode/instances/{$linodeId}/boot";
        $this->action = "boot linnode server";
        $response =  $this->__curlCall();
        return $response;
    }

    //get ips list
    public function getIPs($linodeId)
    {
        $this->endPoint = "linode/instances/{$linodeId}/ips";
        $this->action = "get ips list";
        $response =  $this->__curlCall();
        return $response;
    }

    // get stats of server
    public function getStats($linodeId, $range)
    {
        $this->endPoint = "linode/instances/{$linodeId}/stats/{$range}";
        $this->action = "get status of server";
        $response =  $this->__curlCall();
        return $response;
    }

    //create ip
    public function createIp($linodeId, $public = false)
    {
        $this->method = "POST";
        $this->data = [
            "type" => "ipv4",
            "public" => $public
        ];
        $this->endPoint = "linode/instances/{$linodeId}/ips";
        $this->action = "create ip";
        $response =  $this->__curlCall();
        return $response;
    }

    //edit ip address(rDNS)
    public function editIpRdns($linodeId, $IpAddress, $rDNS)
    {
        $this->method = "PUT";
        $this->data = ["rdns" => $rDNS];
        $this->endPoint = "linode/instances/{$linodeId}/ips/{$IpAddress}";
        $this->action = "edit rDNS";
        $response =  $this->__curlCall();
        return $response;
    }


    // delete ip address 
    public function deleteIp($linodeId, $IpAddress)
    {
        $this->method = "DELETE";
        $this->endPoint = "linode/instances/{$linodeId}/ips/{$IpAddress}";
        $this->action = "Delete public ip";
        $response =  $this->__curlCall();
        return $response;
    }

    // take snapshot
    public function takeSnapshot($linodeId, $label)
    {
        $this->method = "POST";
        $this->data = ["label" => $label];
        $this->endPoint = "linode/instances/{$linodeId}/backups";
        $this->action = "create public ip";
        $response =  $this->__curlCall();
        return $response;
    }

    // get backup details 
    public function getBackupDetail($linodeId)
    {
        $this->endPoint = "linode/instances/{$linodeId}/backups";
        $this->action = "create public ip";
        $response =  $this->__curlCall();
        return $response;
    }

    // enable backup 
    public function backupEnable($linodeId)
    {
        $this->method = "POST";
        $this->endPoint = "linode/instances/{$linodeId}/backups/enable";
        $this->action = "backup enable";
        $response =  $this->__curlCall();
        return $response;
    }
    // disable backup 
    public function disableBackup($linodeId)
    {
        $this->method = "POST";
        $this->endPoint = "linode/instances/{$linodeId}/backups/cancel";
        $this->action = "backup enable";
        $response =  $this->__curlCall();
        return $response;
    }
    //create linode
    public function createLinode($data)
    {
        $this->method = "POST";
        $this->data = $data;
        $this->endPoint = "linode/instances";
        $this->action = "create linode server";
        $response =  $this->__curlCall();
        return $response;
    }
    // getConfigList
    public function getConfigList($linodeId)
    {
        $this->endPoint = "linode/instances/{$linodeId}/configs";
        $this->action = "create linode server";
        $response =  $this->__curlCall();
        return $response;
    }
    // rebuild 
    public function rebuild($linodeId, $post)
    {
        $this->method = "POST";
        $this->data = [
            "image" => $post["Image"],
            "root_pass" => $post["password"]
        ];
        $this->endPoint = "linode/instances/{$linodeId}/rebuild";
        $this->action = "create linode server";
        $response =  $this->__curlCall();
        return $response;
    }

    // restoreBAckup

    public function backupRestore($linodeId, $backupId)
    {
        $this->method = "POST";
        $this->data = [
            "linode_id" => $linodeId,
            "overwrite" => true
        ];
        $this->endPoint = "linode/instances/{$linodeId}/backups/{$backupId}/restore";
        $this->action = "create linode server";
        $response =  $this->__curlCall();
        return $response;
    }

    //  set parameters 
    public function setParams($baseUrl, $apiKey)
    {
        $this->baseUrl = $baseUrl;
        $this->apiKey = $apiKey;
        $this->header = [
            "Authorization: Bearer " . $apiKey,
            "Content-type: application/json"
        ];
    }
}
