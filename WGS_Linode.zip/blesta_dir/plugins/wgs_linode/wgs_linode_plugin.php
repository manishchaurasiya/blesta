<?php

use Blesta\Core\Util\Events\Common\EventInterface;

class WgsLinodePlugin extends Plugin
{
    public function __construct()
    {
        // Load components required by this plugin
        Loader::loadComponents($this, ['Input', 'Record']);
        Language::loadLang("linode_plugin", null, dirname(__FILE__) . DS . "language" . DS);
        $this->loadConfig(dirname(__FILE__) . DS . "config.json");
    }

    public function install($plugin_id)
    {

        if (!$this->tableExist("linode_product_setting")) {
            $this->Record
                ->setField("id", array('type' => "int", 'size' => 11, 'unsigned' => true, 'auto_increment' => true))
                ->setField("company_id", array('type' => "int", 'size' => 11))
                ->setField("product_id", array('type' => "int", 'size' => 11))
                ->setField("linode_plan", array('type' => "text", 'size' => 255))
                ->setField("kernel", array('type' => "text", 'size' => 255))
                ->setField("subscription", array('type' => "int", 'size' => 11))
                ->setField("swap", array('type' => "int", 'size' => 11))
                ->setField("stack_script", array('type' => "int", 'size' => 11))
                ->setField("status", array('type' => "int", 'size' => 11))
                ->setKey(array("id"), "primary")
                ->create("linode_product_setting");
        }


        if (!$this->tableExist("linode_features")) {
            $this->Record
                ->setField("id", array('type' => "int", 'size' => 11, 'unsigned' => true, 'auto_increment' => true))
                ->setField("company_id", array('type' => "int", 'size' => 11))
                ->setField("product_id", array('type' => "int", 'size' => 11))
                ->setField("feature", array('type' => "varchar", 'size' => 255))
                ->setKey(array("id"), "primary")
                ->create("linode_features");
        }


        if (!$this->tableExist("mod_linode_license")) {
            $this->Record
                ->setField("id", array('type' => "int", 'size' => 11, 'unsigned' => true, 'auto_increment' => true))
                ->setField("company_id", array('type' => "int", 'size' => 11))
                ->setField("status", array('type' => "varchar", 'size' => 100))
                ->setKey(array("id"), "primary")
                ->create("mod_linode_license");
        }

        // store invoice detail when user add additional feature from my service tab 
        if (!$this->tableExist("linode_invoice")) {
            $this->Record
                ->setField("id", array('type' => "int", 'size' => 11, 'unsigned' => true, 'auto_increment' => true))
                ->setField("invoice_id", array('type' => "int", 'size' => 11))
                ->setField("service_id", array('type' => "int", 'size' => 11))
                ->setField("action", array('type' => "text", 'size' => 255))
                ->setField("status", array('type' => "text", 'size' => 100))
                ->setKey(array("id"), "primary")
                ->create("linode_invoice");
        }

        if (!$this->tableExist("linode_stackscripts")) {
            $this->Record
                ->setField("id", array('type' => "int", 'size' => 11, 'unsigned' => true, 'auto_increment' => true))
                ->setField("company_id", array('type' => "int", 'size' => 11))
                ->setField("scriptid", array('type' => "int", 'size' => 11))
                ->setField("label", array('type' => "text", 'size' => 255))
                ->setField("description", array('type' => "text", 'size' => 255))
                ->setField("script", array('type' => "text", 'size' => 255))
                ->setField("revision", array('type' => "varchar", 'size' => 255))
                ->setField("images", array('type' => "text", 'size' => 255))
                ->setField("deployments_active", array('type' => "int", 'size' => 11))
                ->setField("is_public", array('type' => "int", 'size' => 11))
                ->setKey(array("id"), "primary")
                ->create("linode_stackscripts");
        }

        Loader::loadHelpers($this, array("Html"));
        Loader::loadModels($this, ['WgsLinode.WgsLinodeHelper']);

        //------------------------ product config options --------------------------------

        $this->WgsLinodeHelper->createConfigOptions();
    }

    public function uninstall($plugin_id, $last_instance)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeLicense', 'Companies']);
        //   echo ("uninstall");
        $companyId = Configure::get('Blesta.company_id');
        foreach ($this->WgsLinodeConfig->settings as $key => $value) {
            $this->Companies->unsetSetting($companyId, $key);
        }
    }

    public function upgrade($current_version, $plugin_id)
    {

        #

        # TODO: Place upgrade logic here

        #

    }


    /**
     * Returns all events to be registered for this plugin
     * (invoked after install() or upgrade(), overwrites all existing events)
     *
     * @return array A numerically indexed array containing:
     *  - event The event to register for
     *  - callback A string or array representing a callback function or class/method.
     *      If a user (e.g. non-native PHP) function or class/method, the plugin must
     *      automatically define it when the plugin is loaded. To invoke an instance
     *      methods pass "this" instead of the class name as the 1st callback element.
     */
    public function getEvents()
    {
        return [
            [
                'event' => "Invoices.setClosed",
                'callback' => ["this", "invoiceSetClosed"]
            ],
            [
                'event' => "Appcontroller.preAction",
                'callback' => ["this", "preAction"]
            ],
        ];
    }


    /**
     * Handler for the Invoices.setClosed event
     *
     * @param EventInterface $event The event to process
     */

    public function invoiceSetClosed(EventInterface $event)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeApi', 'WgsLinode.WgsLinodeHelper', "Invoices", "Services"]);
        Loader::loadComponents($this, ['Input', 'Record']);

        $params = $event->getParams();
        $invoice_id = $params["invoice_id"];
        $service_id = $params["old_invoice"]->line_items["0"]->service_id;
        $service = $this->Services->get($service_id);
        // 
        $exist = $this->WgsLinodeHelper->getData("linode_invoice", ["service_id" => $service_id, "invoice_id" => $invoice_id]);
        if (isset($exist->action) ? $exist->action == "enable_backup" : false) {
            $settings = $this->WgsLinodeHelper->getConfigSetting();
            $this->WgsLinodeApi->setParams($settings['wgs_linode_api_url']->value, $settings['wgs_linode_api_key']->value);
            $linodemeta = $this->WgsLinodeHelper->getLinodeId($service);
            $linodeId =  $linodemeta["linode_id"];
            // echo "<pre>";
            // print_r($linodeId);
            // die;
            // hit backup enable api here
            $response = $this->WgsLinodeApi->backupEnable($linodeId);
            if ($response["httpcode"] == 200) {
                $this->Record->where("service_id", "=", $service_id)->where("action", "=", "enable_backup")->update("linode_invoice", ["status" => "paid"]);
                return true;
            }
            else {
        //error
            }
        }
    }

    /**
     * Handler for the Invoices.setClosed event
     *
     * @param EventInterface $event The event to process
     */

    public function preAction(EventInterface $event)
    {
        Loader::loadModels($this, ['WgsLinode.WgsLinodeConfig', 'WgsLinode.WgsLinodeApi', "Invoices"]);

        // $params = $event->getParams();
        // echo "<pre>";
        // print_r($event);
        // $responce = $this->Record->from("linode_invoice")->where("action", "=", "enable_backup")->delete();
        // exit;
        // }
    }

    public function getActions()
    {
        return array(
            array(
                'action' => "nav_primary_staff", // The action to tie into
                'uri' => "plugin/wgs_linode/admin/dashboard", // The URI to fetch when the action is needed
                'name' => "WgsLinodePlugin.name", // The name used by Blesta to display for the action (e.g. The name of the link),
                'options' => null, // Options required for this action if any (e.g. array('key' => "value"))
                'enabled' => 1 // Whether or not the action should be enabled by default (1 to enable, 0 to disable)
            )
        );
    }


    private function tableExist($table_name)
    {
        try {
            $table_info = $this->Record->query("SELECT TABLE_NAME as table_name FROM information_schema.tables WHERE table_schema = ? OR TABLE_NAME=?", $table_name, $table_name)->fetch();

            if (isset($table_info->table_name)) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return $e;
        }
    }
}
