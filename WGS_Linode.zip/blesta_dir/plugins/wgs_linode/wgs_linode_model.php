<?php
class WgsLinodeModel extends AppModel
{
    public $settings = [
        "wgs_linode_license_key" => "wgs_linode_license_key",
        "wgs_linode_api_url" => "wgs_linode_api_url",
        "wgs_linode_api_key" => "wgs_linode_api_key",
        "wgs_linode_username" => "wgs_linode_username",
        "wgs_linode_prefix" => "wgs_linode_prefix"
    ];

    public $linodeProductFeatures = [
        "reset_root_password",
        "rebuild",
        "ip_list",
        "add_private_ip",
        "add_public_ip",
        "server_activity_log",
        "rescue",
        "rdns",
        "backup"
    ];

    public $customFields = [
        "linode_id" => [
            "type" => "text",
            "admin_only" => true
        ],
        "linode_label" => [
            "type" => "text",
            "admin_only" => true
        ],
        "password" => [
            "type" => "text",
            "admin_only" => true
        ],
        "config_id" => [
            "type" => "text",
            "admin_only" => true
        ],
        "swap_disk_id" => [
            "type" => "text",
            "admin_only" => true
        ],
        "main_disk_id" => [
            "type" => "text",
            "admin_only" => true
        ],
        "reverse_dns" => [
            "type" => "text",
            "admin_only" => true
        ],
        "resoucres_id" => [
            "type" => "text",
            "admin_only" => true
        ],
        "stackscript" => [
            "type" => "select",
            "admin_only" => true
        ],
        "server_image" => [
            "type" => "select"
        ],
        "datacenter" => [
            "type" => "select"
        ],
    ];

    public $datacenter = [
        "ap-west" => 'Mumbai(India)',
        "ca-central" => "Toronto(Canada)",
        "ap-southeast" => "Sydney(Australia)",
        'us-central' => "Dallas(United States)",
        "us-west" => "Fremont(United States)",
        "us-southeast" => "Atlanta(United States)",
        "us-east" => "Newark(United States)",
        "eu-west" => "London(United Kingdom)",
        "ap-south" => "Singapore(Singapore)",
        "eu-central" => "Frankfurt(Germany)",
        "ap-northeast" => "Tokyo(Japan)"
    ];

    public $encryFields = [
        "wgs_linode_api_key" => "wgs_linode_api_key"
    ];

    // client side card  server details
    public $clienSideCard = [
        "server_name" => [
            "server_name" => "label",
            "is_copy" => true
        ],
        "operating_system" => [
            "operating_system" => "image",
            "is_copy" => false
        ],
        "ipv6" => [
            "ipv6" => "ipv6",
            "is_copy" => true
        ],
        "ipv4" => [
            "ipv4" => "ipv4",
            "is_copy" => true
        ],
        "last_updated" => [
            "last_updated" => "updated",
            "is_copy" => false
        ],
    ];

    public function __construct()
    {
        parent::__construct();
        // Auto load language for these models
        Language::loadLang("wgs_linode_plugin", null, dirname(__FILE__) . DS . 'language' . DS);
        Loader::loadModels($this, ['Companies']);
    }
}
